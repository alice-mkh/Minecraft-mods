package net.minecraft.src;

import net.minecraft.src.GuiButtonOldDays;

public class GuiButtonNBXlite extends GuiButtonOldDays{
    public GuiButtonNBXlite(int id, int x, int w){
        super(id, x, 0, w, 20, "");
    }
}