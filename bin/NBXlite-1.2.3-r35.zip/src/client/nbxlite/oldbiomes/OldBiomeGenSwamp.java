package net.minecraft.src.nbxlite.oldbiomes;

public class OldBiomeGenSwamp extends OldBiomeGenBase
{

    public OldBiomeGenSwamp()
    {
    }
}
