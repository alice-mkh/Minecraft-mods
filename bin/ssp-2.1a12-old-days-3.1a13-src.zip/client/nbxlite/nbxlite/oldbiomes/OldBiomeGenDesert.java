package net.minecraft.src.nbxlite.oldbiomes;

public class OldBiomeGenDesert extends OldBiomeGenBase
{

    public OldBiomeGenDesert()
    {
    }
}
