package net.minecraft.src.nbxlite.indev;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.src.Block;

public class IndevLevel{
    public int a;
    public int b;
    public int c;
    public byte d[];
    public String name;
    public String creator;
    public long createTime;
    public int i;
    public int j;
    public int k;
    public float l;
    public int m = Block.waterMoving.blockID;
    List n = new ArrayList();
    public int waterLevel;
    public int t;
    public int u;
    public int v = 10079487;
    public int w = 16777215;
    public int x = 16777215;
    public int A = 15;
    public int B = 15;
    int p[];

    public IndevLevel(){}

    public void a(){}

    public void d(){}
}