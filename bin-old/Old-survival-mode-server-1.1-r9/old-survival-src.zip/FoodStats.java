package net.minecraft.src;

public class FoodStats
{
    private int foodLevel;
    private float foodSaturationLevel;
    private float foodExhaustionLevel;
    private int foodTimer;
    private int prevFoodLevel;

    public FoodStats()
    {
        foodTimer = 0;
        foodLevel = 20;
        prevFoodLevel = 20;
        foodSaturationLevel = 5F;
    }

    public void addFoodAndSaturationLevel(int i, float f)
    {
        if(mod_OldSurvivalMode.DisableHunger){
            foodLevel = 20;
            foodSaturationLevel = 20;
        }else{
            foodLevel = Math.min(i + foodLevel, 20);
            foodSaturationLevel = Math.min(foodSaturationLevel + (float)i * f * 2.0F, foodLevel);
        }
    }

    public void eatFood(ItemFood itemfood)
    {
        addFoodAndSaturationLevel(itemfood.getHealAmount(), itemfood.getSaturationFactor());
    }

    public void update(EntityPlayer entityplayer)
    {
        int i = entityplayer.worldObj.difficultySetting;
        prevFoodLevel = foodLevel;
        if (foodExhaustionLevel > 4F)
        {
            foodExhaustionLevel -= 4F;
            if (foodSaturationLevel > 0.0F)
            {
                foodSaturationLevel = Math.max(foodSaturationLevel - 1.0F, 0.0F);
            }
            else if (i > 0)
            {
                foodLevel = Math.max(foodLevel - 1, 0);
            }
        }
        if (foodLevel >= 18 && entityplayer.mustHeal())
        {
            foodTimer++;
            if(!mod_OldSurvivalMode.DisableHunger){
                if (foodTimer >= 80)
                {
                    entityplayer.heal(1);
                    foodTimer = 0;
                }
            }
        }
        else if (foodLevel <= 0)
        {
            foodTimer++;
            if (foodTimer >= 80)
            {
                if(!mod_OldSurvivalMode.DisableHunger){
                    if(entityplayer.getEntityHealth() > 10 || i >= 3 || entityplayer.getEntityHealth() > 1 && i >= 2)
                    {
                        entityplayer.attackEntityFrom(DamageSource.starve, 1);
                    }
                }
                foodTimer = 0;
            }
        }
        else
        {
            foodTimer = 0;
        }
    }

    public void readNBT(NBTTagCompound nbttagcompound)
    {
        if(nbttagcompound.hasKey("foodLevel"))
        {
            if(mod_OldSurvivalMode.DisableHunger){
                foodLevel = 20;
                foodTimer = 20;
                foodSaturationLevel = 20;
                foodExhaustionLevel = 20;
            }else{
                foodLevel = nbttagcompound.getInteger("foodLevel");
                foodTimer = nbttagcompound.getInteger("foodTickTimer");
                foodSaturationLevel = nbttagcompound.getFloat("foodSaturationLevel");
                foodExhaustionLevel = nbttagcompound.getFloat("foodExhaustionLevel");
            }
        }
    }

    public void writeNBT(NBTTagCompound nbttagcompound)
    {
        if(mod_OldSurvivalMode.DisableHunger){
            nbttagcompound.setInteger("foodLevel", 20);
            nbttagcompound.setInteger("foodTickTimer", 20);
            nbttagcompound.setFloat("foodSaturationLevel", 20);
            nbttagcompound.setFloat("foodExhaustionLevel", 20);
        }else{
            nbttagcompound.setInteger("foodLevel", foodLevel);
            nbttagcompound.setInteger("foodTickTimer", foodTimer);
            nbttagcompound.setFloat("foodSaturationLevel", foodSaturationLevel);
            nbttagcompound.setFloat("foodExhaustionLevel", foodExhaustionLevel);
        }
    }

    public int getFoodLevel()
    {
        if(mod_OldSurvivalMode.DisableHunger){
            return 20;
        }
        return 20;
    }

    public boolean mustEat()
    {
        return foodLevel < 20;
    }

    public void addExhaustion(float f)
    {
        if(!mod_OldSurvivalMode.DisableHunger){
            foodExhaustionLevel = Math.min(foodExhaustionLevel + f, 40F);
        }
    }

    public float getSaturationLevel()
    {
        if(mod_OldSurvivalMode.DisableHunger){
            return 20;
        }
        return foodSaturationLevel;
    }
}
