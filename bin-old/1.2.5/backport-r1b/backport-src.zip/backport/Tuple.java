package net.minecraft.src.backport;

public class Tuple
{
    private Object field_56949_a;
    private Object field_56948_b;

    public Tuple(Object par1Obj, Object par2Obj)
    {
        field_56949_a = par1Obj;
        field_56948_b = par2Obj;
    }

    public Object func_56947_a()
    {
        return field_56949_a;
    }

    public Object func_56946_b()
    {
        return field_56948_b;
    }
}
