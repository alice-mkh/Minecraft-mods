package net.minecraft.src.backport;

import net.minecraft.src.*;

public class ComponentScatteredFeaturePieces1
{
    public ComponentScatteredFeaturePieces1()
    {
    }
}
