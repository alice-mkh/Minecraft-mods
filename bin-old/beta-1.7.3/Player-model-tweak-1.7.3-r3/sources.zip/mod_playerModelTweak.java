package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_playerModelTweak extends BaseMod{
    public String Version(){
	return "1.7.3_r2";
    }

    public mod_playerModelTweak(){
        playerModelTweakProperties playermodeltweakproperties = new playerModelTweakProperties();
        try
        {
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/PlayerModelTweaks.properties").toString());
            boolean flag = file.createNewFile();
            if(flag)
            {
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                playermodeltweakproperties.setProperty("Preset", Integer.toString(DefaultPreset));
                playermodeltweakproperties.setProperty("CustomAnimation", Boolean.toString(DefaultCustom));
                playermodeltweakproperties.setProperty("CustomSpeed", Float.toString(DefaultCustomSpeed));
                playermodeltweakproperties.setProperty("CustomSpeedSneak", Float.toString(DefaultCustomSpeedSneak));
                playermodeltweakproperties.setProperty("CustomArmsX", Float.toString(DefaultCustomArmsX));
                playermodeltweakproperties.setProperty("CustomArmsZ", Float.toString(DefaultCustomArmsZ));
                playermodeltweakproperties.setProperty("CustomArmsXSneak", Float.toString(DefaultCustomArmsXSneak));
                playermodeltweakproperties.setProperty("CustomArmsZSneak", Float.toString(DefaultCustomArmsZSneak));
                playermodeltweakproperties.setProperty("CustomLegsX", Float.toString(DefaultCustomLegsX));
                playermodeltweakproperties.setProperty("CustomLegsZ", Float.toString(DefaultCustomLegsZ));
                playermodeltweakproperties.setProperty("CustomLegsXSneak", Float.toString(DefaultCustomLegsXSneak));
                playermodeltweakproperties.setProperty("CustomLegsZSneak", Float.toString(DefaultCustomLegsZSneak));
                playermodeltweakproperties.setProperty("CustomUpDownAmplitude", Float.toString(DefaultCustomUpDownAmplitude));
                playermodeltweakproperties.setProperty("CustomHeadMode", Integer.toString(DefaultCustomHeadMode));
                playermodeltweakproperties.setProperty("CustomArmsMode", Integer.toString(DefaultCustomArmsMode));
                playermodeltweakproperties.setProperty("CustomItemInHand", Boolean.toString(DefaultCustomItemInHand));
                playermodeltweakproperties.setProperty("CustomUseSwing", Boolean.toString(DefaultCustomUseSwing));
                playermodeltweakproperties.store(fileoutputstream, "Player model tweaks config");

                fileoutputstream.close();
            }
            playermodeltweakproperties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/PlayerModelTweaks.properties").toString()));
            Preset = Integer.parseInt(playermodeltweakproperties.getProperty("Preset"));
	    Custom = Boolean.parseBoolean(playermodeltweakproperties.getProperty("CustomAnimation"));
            CustomSpeed = Float.parseFloat(playermodeltweakproperties.getProperty("CustomSpeed"));
            CustomSpeedSneak = Float.parseFloat(playermodeltweakproperties.getProperty("CustomSpeedSneak"));
            CustomArmsX = Float.parseFloat(playermodeltweakproperties.getProperty("CustomArmsX"));
            CustomArmsZ = Float.parseFloat(playermodeltweakproperties.getProperty("CustomArmsZ"));
            CustomArmsXSneak = Float.parseFloat(playermodeltweakproperties.getProperty("CustomArmsXSneak"));
            CustomArmsZSneak = Float.parseFloat(playermodeltweakproperties.getProperty("CustomArmsZSneak"));
            CustomLegsX = Float.parseFloat(playermodeltweakproperties.getProperty("CustomLegsX"));
            CustomLegsZ = Float.parseFloat(playermodeltweakproperties.getProperty("CustomLegsZ"));
            CustomLegsXSneak = Float.parseFloat(playermodeltweakproperties.getProperty("CustomLegsXSneak"));
            CustomLegsZSneak = Float.parseFloat(playermodeltweakproperties.getProperty("CustomLegsZSneak"));
            CustomUpDownAmplitude = Float.parseFloat(playermodeltweakproperties.getProperty("CustomUpDownAmplitude"));
            CustomHeadMode = Integer.parseInt(playermodeltweakproperties.getProperty("CustomHeadMode"));
            CustomArmsMode = Integer.parseInt(playermodeltweakproperties.getProperty("CustomArmsMode"));
	    CustomItemInHand = Boolean.parseBoolean(playermodeltweakproperties.getProperty("CustomItemInHand"));
	    CustomUseSwing = Boolean.parseBoolean(playermodeltweakproperties.getProperty("CustomUseSwing"));
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
    }
    public static int Preset;
    public static boolean Custom;
    public static float CustomSpeed;
    public static float CustomSpeedSneak;
    public static float CustomLegsX;
    public static float CustomLegsXSneak;
    public static float CustomLegsZ;
    public static float CustomLegsZSneak;
    public static float CustomArmsX;
    public static float CustomArmsXSneak;
    public static float CustomArmsZ;
    public static float CustomArmsZSneak;
    public static int CustomHeadMode;
    public static float CustomUpDownAmplitude;
    public static int CustomArmsMode;
    public static boolean CustomItemInHand;
    public static boolean CustomUseSwing;

    public static int DefaultPreset = 2;
    public static boolean DefaultCustom = false;
    public static float DefaultCustomSpeed = 1F;
    public static float DefaultCustomSpeedSneak = 1F;
    public static float DefaultCustomLegsX = 1.4F;
    public static float DefaultCustomLegsXSneak = 1.4F;
    public static float DefaultCustomLegsZ = 0F;
    public static float DefaultCustomLegsZSneak = 0F;
    public static float DefaultCustomArmsX = 1F;
    public static float DefaultCustomArmsXSneak = 1F;
    public static float DefaultCustomArmsZ = 0.05F;
    public static float DefaultCustomArmsZSneak = 0F;
    public static int DefaultCustomHeadMode = 1;
    public static float DefaultCustomUpDownAmplitude = 0F;
    public static int DefaultCustomArmsMode = 1;
    public static boolean DefaultCustomItemInHand = true;
    public static boolean DefaultCustomUseSwing = true;
}