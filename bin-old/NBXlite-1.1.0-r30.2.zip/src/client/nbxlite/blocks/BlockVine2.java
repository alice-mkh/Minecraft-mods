package net.minecraft.src.nbxlite.blocks;

import java.util.Random;
import net.minecraft.src.mod_noBiomesX;
import net.minecraft.src.BlockVine;
import net.minecraft.src.ColorizerFoliage;
import net.minecraft.src.IBlockAccess;

public class BlockVine2 extends BlockVine
{
    public BlockVine2(int i)
    {
        super(i);
    }

    public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if (mod_noBiomesX.Generator==2){
            return iblockaccess.getWorldChunkManager().getBiomeGenAt(i, k).getFoliageColorAtCoords(iblockaccess, i, j, k);
        }else if (mod_noBiomesX.Generator==1){
            iblockaccess.getWorldChunkManager().oldFunc_4069_a(i, k, 1, 1);
            double d = iblockaccess.getWorldChunkManager().temperature[0];
            double d1 = iblockaccess.getWorldChunkManager().humidity[0];
            return ColorizerFoliage.getFoliageColor(d, d1);
        }else{
            return 0x5fff3f;
        }
    }
}
