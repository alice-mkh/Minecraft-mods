package net.minecraft.src;

import net.minecraft.server.MinecraftServer;
import java.io.*;

public class mod_noBiomesX extends BaseModMp{
    public mod_noBiomesX(){
        PropertyManager pmanager = new PropertyManager(new File("server.properties"));
        Generator = pmanager.getIntProperty("generator", 2);
        MapFeatures = pmanager.getIntProperty("features", 0);
        MapTheme = pmanager.getIntProperty("theme", 0);
        SnowCovered = pmanager.getBooleanProperty("snowcovered", false);
    }

    public void ModsLoaded(){
        ModLoaderMp.Log("=========================");
        if (Generator==0){
            ModLoaderMp.Log(" Map generator: ALPHA");
            if (SnowCovered==true){
                ModLoaderMp.Log(" Snow covered: TRUE");
            }else{
                ModLoaderMp.Log(" Snow covered: FALSE");
            }
            if (MapTheme==0){
                ModLoaderMp.Log(" Map theme: NORMAL");
            }else if (MapTheme==1){
                ModLoaderMp.Log(" Map theme: HELL");
            }else if (MapTheme==2){
                ModLoaderMp.Log(" Map theme: WOODS");
            }else if (MapTheme==3){
                ModLoaderMp.Log(" Map theme: PARADISE");
            }
        } else if (Generator==1){
            ModLoaderMp.Log(" Map generator: BETA");
            if (MapFeatures==0){
                ModLoaderMp.Log(" Map features: HALLOWEEN");
            }else if (MapFeatures==1){
                ModLoaderMp.Log(" Map features: 1.4");
            }else if (MapFeatures==2){
                ModLoaderMp.Log(" Map features: 1.7.3");
            }
        } else if (Generator==2){
            ModLoaderMp.Log(" Map generator: 1.0");
        }
        ModLoaderMp.Log(" Structures: ON");
        ModLoaderMp.Log("=========================");
    }

    public String Version(){
        return "1.0.0";
    }
    
    public void SendGeneratorInfo(EntityPlayerMP entityplayermp)
    {
        int[] dataInt = new int[4];
        dataInt[0] = Generator;
        dataInt[1] = MapFeatures;
        dataInt[2] = MapTheme;
        if (SnowCovered==true){
            dataInt[3] = 1;
        }else{
            dataInt[3] = 0;
        }
        Packet230ModLoader packet = new Packet230ModLoader();
        packet.packetType = 0;
        packet.dataInt = dataInt;
        ModLoaderMp.SendPacketTo(this, entityplayermp, packet);
    }
    
    public void HandlePacket(Packet230ModLoader packet, EntityPlayerMP player)
    {
        switch(packet.packetType)
        {
            case 1:
            {
                SendGeneratorInfo(player);
            }
        }
    }

    public void HandleLogin(EntityPlayerMP entityplayermp)
    {
        SendGeneratorInfo(entityplayermp);
    }

    public static int Generator = 1; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean OldSpawners = false;
    public static boolean GenerateSandstone = true;
    public static boolean GenerateLapis = true;
    public static boolean SnowCovered = false;
    public static boolean ClassicLight=true;
    public static boolean GenStructures=false;
    public static int MapTheme = 0;   //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    public static int MapFeatures = 2;   //0 - nothing; 1 - special trees and lakes; 2 - tall grass and weather
}