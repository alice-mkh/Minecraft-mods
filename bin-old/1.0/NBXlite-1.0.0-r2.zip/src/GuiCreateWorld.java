// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode fieldsfirst 

package net.minecraft.src;

import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

// Referenced classes of package net.minecraft.src:
//            GuiScreen, StatCollector, GuiTextField, StringTranslate, 
//            GuiButton, ChatAllowedCharacters, MathHelper, ISaveFormat, 
//            PlayerControllerCreative, PlayerControllerSP, WorldSettings

public class GuiCreateWorld extends GuiScreen
{

    private GuiScreen parentGuiScreen;
    private GuiTextField textboxWorldName;
    private GuiTextField textboxSeed;
    private String folderName;
    private String gameMode;
    private String generator;
    private String generatorExtra;
    private boolean field_35365_g;
    private boolean field_40232_h;
    private boolean createClicked;
    private boolean moreOptions;
    private GuiButton gameModeButton;
    private GuiButton moreWorldOptions;
    private GuiButton generateStructuresButton;
    private GuiButton worldTypeButton;
    private GuiButton generatorButton;
    private GuiButton generatorExtraButton;
    private String gameModeDescriptionLine1;
    private String gameModeDescriptionLine2;
    private String seed;
    private String localizedNewWorldText;

    public GuiCreateWorld(GuiScreen guiscreen)
    {
        gameMode = "survival";
        generator = "beta";
        generatorExtra = "173";
        field_35365_g = true;
        field_40232_h = false;
        parentGuiScreen = guiscreen;
        seed = "";
        localizedNewWorldText = StatCollector.translateToLocal("selectWorld.newWorld");
    }

    public void updateScreen()
    {
        textboxWorldName.updateCursorCounter();
        textboxSeed.updateCursorCounter();
    }

    public void initGui()
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();
        Keyboard.enableRepeatEvents(true);
        controlList.clear();
        controlList.add(new GuiButton(0, width / 2 - 155, height - 28, 150, 20, stringtranslate.translateKey("selectWorld.create")));
        controlList.add(new GuiButton(1, width / 2 + 5, height - 28, 150, 20, stringtranslate.translateKey("gui.cancel")));
        controlList.add(gameModeButton = new GuiButton(2, width / 2 - 75, 100, 150, 20, stringtranslate.translateKey("selectWorld.gameMode")));
        controlList.add(moreWorldOptions = new GuiButton(3, width / 2 - 75, 172, 150, 20, stringtranslate.translateKey("selectWorld.moreWorldOptions")));
        controlList.add(generateStructuresButton = new GuiButton(4, width / 2 - 155, 100, 150, 20, stringtranslate.translateKey("selectWorld.mapFeatures")));
        controlList.add(generatorButton = new GuiButton(6, width / 2 - 155, 135, 150, 20, stringtranslate.translateKey("Generator: Beta")));
        generatorButton.drawButton = false;
        controlList.add(generatorExtraButton = new GuiButton(7, width / 2 + 5, 135, 150, 20, stringtranslate.translateKey("Features: 1.7.3")));
        generatorExtraButton.drawButton = false;
        generateStructuresButton.drawButton = false;
        controlList.add(worldTypeButton = new GuiButton(5, width / 2 + 5, 100, 150, 20, stringtranslate.translateKey("selectWorld.mapType")));
        worldTypeButton.drawButton = false;
        worldTypeButton.enabled = false;
        textboxWorldName = new GuiTextField(this, fontRenderer, width / 2 - 100, 60, 200, 20, localizedNewWorldText);
        textboxWorldName.isFocused = true;
        textboxWorldName.setMaxStringLength(32);
        textboxSeed = new GuiTextField(this, fontRenderer, width / 2 - 100, 60, 200, 20, seed);
        makeUseableName();
        func_35363_g();
    }

    private void makeUseableName()
    {
        folderName = textboxWorldName.getText().trim();
        char ac[] = ChatAllowedCharacters.allowedCharactersArray;
        int i = ac.length;
        for(int j = 0; j < i; j++)
        {
            char c = ac[j];
            folderName = folderName.replace(c, '_');
        }

        if(MathHelper.stringNullOrLengthZero(folderName))
        {
            folderName = "World";
        }
        folderName = generateUnusedFolderName(mc.getSaveLoader(), folderName);
    }

    private void func_35363_g()
    {
        StringTranslate stringtranslate;
        stringtranslate = StringTranslate.getInstance();
        gameModeButton.displayString = (new StringBuilder()).append(stringtranslate.translateKey("selectWorld.gameMode")).append(" ").append(stringtranslate.translateKey((new StringBuilder()).append("selectWorld.gameMode.").append(gameMode).toString())).toString();
        gameModeDescriptionLine1 = stringtranslate.translateKey((new StringBuilder()).append("selectWorld.gameMode.").append(gameMode).append(".line1").toString());
        gameModeDescriptionLine2 = stringtranslate.translateKey((new StringBuilder()).append("selectWorld.gameMode.").append(gameMode).append(".line2").toString());
        generateStructuresButton.displayString = (new StringBuilder()).append(stringtranslate.translateKey("selectWorld.mapFeatures")).append(" ").toString();
        if(field_35365_g)
        {
            generateStructuresButton.displayString += stringtranslate.translateKey("options.on");
        }
        else
        {
            generateStructuresButton.displayString += stringtranslate.translateKey("options.off");
        }
        worldTypeButton.displayString = (new StringBuilder()).append(stringtranslate.translateKey("selectWorld.mapType")).append(" ").append(stringtranslate.translateKey("selectWorld.mapType.normal")).toString();
        return;
    }

    public static String generateUnusedFolderName(ISaveFormat isaveformat, String s)
    {
        for(; isaveformat.getWorldInfo(s) != null; s = (new StringBuilder()).append(s).append("-").toString()) { }
        return s;
    }

    public void onGuiClosed()
    {
        Keyboard.enableRepeatEvents(false);
    }

    protected void actionPerformed(GuiButton guibutton)
    {
        if(!guibutton.enabled)
        {
            return;
        }
        if(guibutton.id == 1)
        {
            mc.displayGuiScreen(parentGuiScreen);
        } else
        if(guibutton.id == 0)
        {
            mc.displayGuiScreen(null);
            if(createClicked)
            {
                return;
            }
            createClicked = true;
            long l = (new Random()).nextLong();
            String s = textboxSeed.getText();
            if(!MathHelper.stringNullOrLengthZero(s))
            {
                try
                {
                    long l1 = Long.parseLong(s);
                    if(l1 != 0L)
                    {
                        l = l1;
                    }
                }
                catch(NumberFormatException numberformatexception)
                {
                    l = s.hashCode();
                }
            }
            int i = 0;
            if(gameMode.equals("creative"))
            {
                i = 1;
                mc.playerController = new PlayerControllerCreative(mc);
            } else
            {
                mc.playerController = new PlayerControllerSP(mc);
            }
            if(generator.equals("beta")){
                mod_noBiomesX.Generator=1;
            }else if(generator.equals("beta2")){
                mod_noBiomesX.Generator=2;
            }else{
                mod_noBiomesX.Generator=0;
            }
            if(generatorExtra.equals("hell")){
                mod_noBiomesX.MapType=1;
            }else if(generatorExtra.equals("woods")){
                mod_noBiomesX.MapType=2;
            }else if(generatorExtra.equals("paradise")){
                mod_noBiomesX.MapType=3;
            }else{
                mod_noBiomesX.MapType=0;
            }
            if(generatorExtra.equals("173")){
                mod_noBiomesX.MapFeatures=2;
            }else if(generatorExtra.equals("140")){
                mod_noBiomesX.MapFeatures=3;
            }else{
                mod_noBiomesX.MapFeatures=1;
            }
            mc.startWorld(folderName, textboxWorldName.getText(), new WorldSettings(l, i, field_35365_g, field_40232_h));
            mc.displayGuiScreen(null);
        } else
        if(guibutton.id == 3)
        {
            moreOptions = !moreOptions;
            gameModeButton.drawButton = !moreOptions;
            generateStructuresButton.drawButton = moreOptions;
            worldTypeButton.drawButton = moreOptions;
            generatorButton.drawButton = moreOptions;
            generatorExtraButton.drawButton = moreOptions;
            if(moreOptions)
            {
                StringTranslate stringtranslate = StringTranslate.getInstance();
                moreWorldOptions.displayString = stringtranslate.translateKey("gui.done");
            } else
            {
                StringTranslate stringtranslate1 = StringTranslate.getInstance();
                moreWorldOptions.displayString = stringtranslate1.translateKey("selectWorld.moreWorldOptions");
            }
        } else
        if(guibutton.id == 2)
        {
            if(gameMode.equals("survival"))
            {
                field_40232_h = false;
                gameMode = "hardcore";
                field_40232_h = true;
                func_35363_g();
            } else
            if(gameMode.equals("hardcore"))
            {
                field_40232_h = false;
                gameMode = "creative";
                func_35363_g();
                field_40232_h = false;
            } else
            {
                gameMode = "survival";
                func_35363_g();
                field_40232_h = false;
            }
            func_35363_g();
        } else
        if(guibutton.id == 4)
        {
            field_35365_g = !field_35365_g;
            func_35363_g();
        } else
        if(guibutton.id == 6)
        {
            if(generator.equals("beta"))
            {
                generator = "beta2";
                generatorButton.displayString = "Generator: Release";
                generatorExtraButton.displayString = "Features: 1.0.0";
                generatorExtraButton.enabled = false;
                generatorExtra = "";
            } else if(generator.equals("beta2"))
            {
                generator = "alpha";
                generatorButton.displayString = "Generator: Alpha";
                generatorExtra = "normal";
                generatorExtraButton.displayString = "Theme: Normal";
                generatorExtraButton.enabled = true;
            } else if(generator.equals("alpha"))
            {
                generator = "beta";
                generatorButton.displayString = "Generator: Beta";
                generatorExtra = "173";
                generatorExtraButton.displayString = "Features: 1.7.3";
            }
        } else
        if(guibutton.id == 7)
        {
            if(generatorExtra.equals("normal"))
            {
                generatorExtra = "hell";
                generatorExtraButton.displayString = "Theme: Hell";
            } else
            if(generatorExtra.equals("hell"))
            {
                generatorExtra = "woods";
                generatorExtraButton.displayString = "Theme: Woods";
            } else
            if(generatorExtra.equals("woods"))
            {
                generatorExtra = "paradise";
                generatorExtraButton.displayString = "Theme: Paradise";
            } else
            if(generatorExtra.equals("paradise"))
            {
                generatorExtra = "normal";
                generatorExtraButton.displayString = "Theme: Normal";
            } else
            if(generatorExtra.equals("120"))
            {
                generatorExtra = "14";
                generatorExtraButton.displayString = "Features: 1.4";
            } else
            if(generatorExtra.equals("14"))
            {
                generatorExtra = "173";
                generatorExtraButton.displayString = "Features: 1.7.3";
            } else
            if(generatorExtra.equals("173"))
            {
                generatorExtra = "120";
                generatorExtraButton.displayString = "Features: 1.2.0";
            }
        }
    }

    protected void keyTyped(char c, int i)
    {
        if(textboxWorldName.isFocused && !moreOptions)
        {
            textboxWorldName.textboxKeyTyped(c, i);
            localizedNewWorldText = textboxWorldName.getText();
        } else
        if(textboxSeed.isFocused && moreOptions)
        {
            textboxSeed.textboxKeyTyped(c, i);
            seed = textboxSeed.getText();
        }
        if(c == '\r')
        {
            actionPerformed((GuiButton)controlList.get(0));
        }
        ((GuiButton)controlList.get(0)).enabled = textboxWorldName.getText().length() > 0;
        makeUseableName();
    }

    protected void mouseClicked(int i, int j, int k)
    {
        super.mouseClicked(i, j, k);
        if(!moreOptions)
        {
            textboxWorldName.mouseClicked(i, j, k);
        } else
        {
            textboxSeed.mouseClicked(i, j, k);
        }
    }

    public void drawScreen(int i, int j, float f)
    {
        StringTranslate stringtranslate = StringTranslate.getInstance();
        drawDefaultBackground();
        drawCenteredString(fontRenderer, stringtranslate.translateKey("selectWorld.create"), width / 2, 20, 0xffffff);
        if(!moreOptions)
        {
            drawString(fontRenderer, stringtranslate.translateKey("selectWorld.enterName"), width / 2 - 100, 47, 0xa0a0a0);
            drawString(fontRenderer, (new StringBuilder()).append(stringtranslate.translateKey("selectWorld.resultFolder")).append(" ").append(folderName).toString(), width / 2 - 100, 85, 0xa0a0a0);
            textboxWorldName.drawTextBox();
            drawString(fontRenderer, gameModeDescriptionLine1, width / 2 - 100, 122, 0xa0a0a0);
            drawString(fontRenderer, gameModeDescriptionLine2, width / 2 - 100, 134, 0xa0a0a0);
        } else
        {
            drawString(fontRenderer, stringtranslate.translateKey("selectWorld.enterSeed"), width / 2 - 100, 47, 0xa0a0a0);
            drawString(fontRenderer, stringtranslate.translateKey("selectWorld.seedInfo"), width / 2 - 100, 85, 0xa0a0a0);
            drawString(fontRenderer, stringtranslate.translateKey("selectWorld.mapFeatures.info"), width / 2 - 150, 122, 0xa0a0a0);
            textboxSeed.drawTextBox();
        }
        super.drawScreen(i, j, f);
    }

    public void selectNextField()
    {
        if(textboxWorldName.isFocused)
        {
            textboxWorldName.setFocused(false);
            textboxSeed.setFocused(true);
        } else
        {
            textboxWorldName.setFocused(true);
            textboxSeed.setFocused(false);
        }
    }
}
