package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class mod_noBiomesX extends BaseMod{
    public mod_noBiomesX(){}

    public void load(){
        Block.grass.toptex = ModLoader.addOverride("/terrain.png", "/nbx/grasstop.png");
        Block.grass.sidetex = ModLoader.addOverride("/terrain.png", "/nbx/grassside.png");
        Block.leaves.fasttex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfast.png");
        Block.leaves.fancytex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfancy.png");
    }

    public String getVersion(){
        return "1.0.0";
    }

    public static int Generator = 1; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean OldSpawners = true;
    public static boolean GenerateSandstone = false;
    public static boolean GenerateLapis = false;
    public static boolean SunriseEffect = false;
    public static boolean LowHangingClouds = true;
    public static boolean OverrideGenerateStructures;
    public static boolean ClassicLight=true;
    public static int LightTintRed = 255;
    public static int LightTintGreen = 255;
    public static int LightTintBlue = 255;
    public static boolean VoidFog=true;
    public static int MapType = 0;   //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    public static int MapFeatures;   //0 - nothing; 1 - special trees; 2 - special trees and tall grass
}