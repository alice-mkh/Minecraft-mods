package net.minecraft.src;
import java.util.*;
import net.minecraft.client.Minecraft;

public class mod_SpawnHuman extends BaseMod{
    public String getVersion(){
		return "1.0_r2";
    }
    
    public mod_SpawnHuman(){
        ModLoader.RegisterKey(this, this.key_spawn, false);
        ModLoader.AddLocalization("key_spawn", "Spawn Human");
        ModLoader.RegisterEntityID(EntityHuman.class, "human", ModLoader.getUniqueEntityId());
    }
    
    public void KeyboardEvent(KeyBinding keybinding){
        Minecraft mc = ModLoader.getMinecraftInstance();
        EntityPlayer entityplayer = mc.thePlayer;
        World theWorld = mc.theWorld;
		PlayerController playerController = mc.playerController;
        if(!theWorld.multiplayerWorld && playerController.isInCreativeMode())
        {
            EntityLiving entityliving = (EntityLiving)EntityList.createEntityInWorld("human", theWorld);
            entityliving.setLocationAndAngles(entityplayer.posX, entityplayer.posY - 1.62D, entityplayer.posZ, theWorld.rand.nextFloat() * 360F, 0.0F);
            theWorld.entityJoinedWorld(entityliving);
            entityliving.spawnExplosionParticle();
        }
    }
    
    public void AddRenderer(Map map){   
        map.put(net.minecraft.src.EntityHuman.class, new RenderHuman(new ModelHuman(), 0.5F));
    }
    
	public void load(){};

    public KeyBinding key_spawn = new KeyBinding("key_spawn", 34);
}