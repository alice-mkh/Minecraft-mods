package net.minecraft.src;

import java.util.List;
import java.util.Random;

public class EntityPigZombie2 extends EntityPigZombie
{
    public EntityPigZombie2(World world)
    {
        super(world);
    }

    protected void dropFewItems(boolean flag, int i)
    {
        int j = rand.nextInt(2 + i);
        if (!mod_OldSurvivalMode.OldDrops){
            for (int k = 0; k < j; k++)
            {
                dropItem(Item.rottenFlesh.shiftedIndex, 1);
            }

            j = rand.nextInt(2 + i);
            for (int l = 0; l < j; l++)
            {
                dropItem(Item.goldNugget.shiftedIndex, 1);
            }
        }else{
            int k = rand.nextInt(3);
            if (i > 0)
            {
                k += rand.nextInt(i + 1);
            }
            for (int l = 0; l < k; l++)
            {
                dropItem(Item.porkCooked.shiftedIndex, 1);
            }
        }
    }

    protected int getDropItemId()
    {
//         return Item.rottenFlesh.shiftedIndex;
        return Item.porkCooked.shiftedIndex;
    }
}