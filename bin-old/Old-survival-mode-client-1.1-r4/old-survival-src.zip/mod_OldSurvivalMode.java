package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_OldSurvivalMode extends BaseMod{
    public String getVersion(){
        return "1.1";
    }

    public mod_OldSurvivalMode(){
        OldSurvivalModeProperties oldsurvivalmodeproperties = new OldSurvivalModeProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                oldsurvivalmodeproperties.setProperty("AnimalsFleeWhenDamaged", Boolean.toString(DefaultAnimalsFlee));
                oldsurvivalmodeproperties.setProperty("DisableFoodStacking", Boolean.toString(DefaultDisableFoodStacking));
                oldsurvivalmodeproperties.setProperty("InstantBow", Boolean.toString(DefaultInstantBow));
                oldsurvivalmodeproperties.setProperty("InstantFood", Boolean.toString(DefaultInstantFood));
                oldsurvivalmodeproperties.setProperty("DisableHunger", Boolean.toString(DefaultDisableHunger));
                oldsurvivalmodeproperties.setProperty("DisableXP", Boolean.toString(DefaultDisableXP));
                oldsurvivalmodeproperties.store(fileoutputstream, "Survival mode config");

                fileoutputstream.close();
            }
            oldsurvivalmodeproperties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString()));
            DisableXP = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableXP"));
            DisableHunger = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableHunger"));
            InstantFood = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantFood"));
            InstantBow = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantBow"));
            DisableFoodStacking = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableFoodStacking"));
            AnimalsFlee = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("AnimalsFleeWhenDamaged"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
    }

    public void load(){};

    public static boolean DisableXP;
    public static boolean DisableHunger;
    public static boolean InstantFood;
    public static boolean InstantBow;
    public static boolean DisableFoodStacking;
    public static boolean AnimalsFlee;

    public static boolean DefaultDisableXP = true;
    public static boolean DefaultDisableHunger = true;
    public static boolean DefaultInstantFood = true;
    public static boolean DefaultInstantBow = true;
    public static boolean DefaultDisableFoodStacking = true;
    public static boolean DefaultAnimalsFlee = true;
}