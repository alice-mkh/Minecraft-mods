package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.io.*;

public class mod_noBiomesX extends BaseModMp{
    public mod_noBiomesX(){
        NBXliteProperties properties = new NBXliteProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                properties.setProperty("DefaultGenerator",Integer.toString(2));
                properties.setProperty("DefaultFeatures",Integer.toString(2));
                properties.setProperty("DefaultTheme",Integer.toString(0));
                properties.store(fileoutputstream,"NBXlite properties");
                fileoutputstream.close();
            }
            properties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString()));
            DefaultGenerator = Integer.parseInt(properties.getProperty("DefaultGenerator"));
            DefaultFeatures = Integer.parseInt(properties.getProperty("DefaultFeatures"));
            DefaultTheme = Integer.parseInt(properties.getProperty("DefaultTheme"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
    }
    
    public void load(){
        Block.grass.toptex = ModLoader.addOverride("/terrain.png", "/nbx/grasstop.png");
        Block.grass.sidetex = ModLoader.addOverride("/terrain.png", "/nbx/grassside.png");
        Block.leaves.fasttex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfast.png");
        Block.leaves.fancytex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfancy.png");
        ModLoader.AddLocalization("nbxlite.genInfdev", "Generator: Infdev");
        ModLoader.AddLocalization("nbxlite.genAlpha", "Generator: Alpha");
        ModLoader.AddLocalization("nbxlite.genBeta", "Generator: Beta");
        ModLoader.AddLocalization("nbxlite.genRelease", "Generator: Release");
        ModLoader.AddLocalization("nbxlite.featuresHalloween", "Features: Alpha 1.2.0");
        ModLoader.AddLocalization("nbxlite.featuresBeta12", "Features: Beta 1.2");
        ModLoader.AddLocalization("nbxlite.featuresBeta14", "Features: Beta 1.4");
        ModLoader.AddLocalization("nbxlite.featuresBeta173", "Features: Beta 1.7.3");
        ModLoader.AddLocalization("nbxlite.featuresBeta181", "Features: Beta 1.8.1");
        ModLoader.AddLocalization("nbxlite.features10", "Features: 1.0");
        ModLoader.AddLocalization("nbxlite.features11", "Features: 1.1");
        ModLoader.AddLocalization("nbxlite.themeNormal", "Theme: Normal");
        ModLoader.AddLocalization("nbxlite.themeHell", "Theme: Hell");
        ModLoader.AddLocalization("nbxlite.themeWoods", "Theme: Woods");
        ModLoader.AddLocalization("nbxlite.themeParadise", "Theme: Paradise");
        ModLoader.AddLocalization("nbxlite.descriptionGenInfdev", "No biomes, large trees");
        ModLoader.AddLocalization("nbxlite.descriptionGenAlpha", "No biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenBeta", "Small biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenRelease", "Large biomes, villages");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesHalloween", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta12", "Lakes, special trees");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta14", "Sandstone");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta173", "Tall grass, weather");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta181", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures10", "Snow, mushrooms, dark swamps");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures11", "Snow in taiga, beaches, hills");
        ModLoader.AddLocalization("nbxlite.descriptionThemeNormal", "Blue sky, green grass");
        ModLoader.AddLocalization("nbxlite.descriptionThemeHell", "Dark world with lava oceans");
        ModLoader.AddLocalization("nbxlite.descriptionThemeWoods", "Cloudy sky, many trees");
        ModLoader.AddLocalization("nbxlite.descriptionThemeParadise", "Eternal day, large beaches");
    }

    public String getVersion(){
        return "1.1.0";
    }

    public void HandlePacket(Packet230ModLoader packet)
    {
        switch(packet.packetType)
        {
            case 0:
            {
                Generator=packet.dataInt[0];
                if (packet.dataInt[0]==0){
                    MapTheme=packet.dataInt[2];
                    ModLoader.getMinecraftInstance().theWorld.setWorldTheme();
                    if (packet.dataInt[3]==1){
                        SnowCovered=true;
                    }else{
                        SnowCovered=false;
                    }
                }else if (packet.dataInt[0]==1 || packet.dataInt[0]==2){
                    MapFeatures=packet.dataInt[1];
                }
                if (packet.dataInt[0]==0){
                    mod_noBiomesX.SunriseEffect=false;
    //                 mod_noBiomesX.OldSpawners=true;
                }else{
                    mod_noBiomesX.SunriseEffect=true;
    //                 mod_noBiomesX.OldSpawners=false;
                }
                if (packet.dataInt[0]==2){
                    mod_noBiomesX.LowHangingClouds=false;
                    mod_noBiomesX.ClassicLight=false;
                    mod_noBiomesX.VoidFog=true;
                }else{
                    mod_noBiomesX.LowHangingClouds=true;
                    mod_noBiomesX.ClassicLight=true;
                    mod_noBiomesX.VoidFog=false;
                }
                if (packet.dataInt[0]==2 || (packet.dataInt[0]==1 && packet.dataInt[1]!=0)){
                    mod_noBiomesX.GenerateSandstone=true;
                }else{
                    mod_noBiomesX.GenerateSandstone=false;
                }
            }
        }
    }

    public void RequestGeneratorInfo()
    {
        Packet230ModLoader packet = new Packet230ModLoader();
        packet.packetType = 1;
        ModLoaderMp.SendPacket(this,packet);
    }

    public static int Generator = 2; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean OldSpawners = false;
    public static boolean GenerateSandstone = true;
    public static boolean GenerateLapis = true;
    public static boolean SunriseEffect = true;
    public static boolean SnowCovered = false;
    public static boolean LowHangingClouds = false;
    public static boolean ClassicLight=true;
    public static int LightTintRed = 255;
    public static int LightTintGreen = 255;
    public static int LightTintBlue = 255;
    public static boolean VoidFog=false;
    public static boolean GreenGrassSides=false;
    public static boolean InfdevCaves=false;
    public static int MapTheme = 0;  //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    public static int MapFeatures;   //for alpha: 0 - alpha; 1 - infdev; for beta: 0 - halloween; 1 - beta 1.2; 2 - beta 1.4; 3 - beta 1.7.3; for release: 0 - Beta 1.8; 1 - 1.0; 2 - 1.1
    public static int DefaultGenerator;
    public static int DefaultFeatures;
    public static int DefaultTheme;
}