package net.minecraft.src;

import java.util.List;

public class ChunkProviderGenerate
    implements IChunkProvider
{
    public ChunkProviderGenerateInfdev infdevGen;
    public ChunkProviderGenerateAlpha alphaGen;
    public ChunkProviderGenerateBeta betaGen;
    public ChunkProviderGenerateRelease releaseGen;

    public ChunkProviderGenerate(World world, long l, boolean flag)
    {
        infdevGen = new ChunkProviderGenerateInfdev(world, l, flag);
        alphaGen = new ChunkProviderGenerateAlpha(world, l, flag);
        betaGen = new ChunkProviderGenerateBeta(world, l, flag);
        releaseGen = new ChunkProviderGenerateRelease(world, l, flag);
    }

    public Chunk loadChunk(int i, int j)
    {
        return provideChunk(i, j);
    }

    public Chunk provideChunk(int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                return alphaGen.provideChunk(i, j);
            }else{
                return infdevGen.provideChunk(i, j);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.provideChunk(i, j);
        } else
        {
            return releaseGen.provideChunk(i, j);
        }
    }

    public boolean chunkExists(int i, int j)
    {
        return true;
    }

    public void populate(IChunkProvider ichunkprovider, int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                alphaGen.populate(ichunkprovider, i, j);
            }else{
                infdevGen.populate(ichunkprovider, i, j);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            betaGen.populate(ichunkprovider, i, j);
        } else
        {
            releaseGen.populate(ichunkprovider, i, j);
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unload100OldestChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public List func_40181_a(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==2){
            return releaseGen.func_40377_a_release(enumcreaturetype,i,j,k);
        }
        return null;
    }

    public ChunkPosition func_40182_a(World world, String s, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                return alphaGen.func_40182_a(world, s, i, j, k);
            }else{
                return infdevGen.func_40182_a(world, s, i, j, k);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.func_40182_a(world, s, i, j, k);
        } else
        {
            return releaseGen.func_40182_a(world, s, i, j, k);
        }
    }
}
