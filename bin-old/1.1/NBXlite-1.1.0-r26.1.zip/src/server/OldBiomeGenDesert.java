package net.minecraft.src;

public class OldBiomeGenDesert extends OldBiomeGenBase
{

    public OldBiomeGenDesert()
    {
    }
}
