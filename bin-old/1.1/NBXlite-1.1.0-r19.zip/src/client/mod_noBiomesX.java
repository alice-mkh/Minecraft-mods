package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.io.*;

public class mod_noBiomesX extends BaseModMp{
    public mod_noBiomesX(){
        NBXliteProperties properties = new NBXliteProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                properties.setProperty("DefaultGenerator",Integer.toString(2));
                properties.setProperty("DefaultFeatures",Integer.toString(2));
                properties.setProperty("DefaultTheme",Integer.toString(0));
                properties.setProperty("UseNewSpawning",Boolean.toString(false));
                properties.setProperty("BetaGreenGrassSides",Boolean.toString(true));
                properties.store(fileoutputstream,"NBXlite properties");
                fileoutputstream.close();
            }
            properties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString()));
            DefaultGenerator = Integer.parseInt(properties.getProperty("DefaultGenerator"));
            DefaultFeatures = Integer.parseInt(properties.getProperty("DefaultFeatures"));
            DefaultTheme = Integer.parseInt(properties.getProperty("DefaultTheme"));
            UseNewSpawning = Boolean.parseBoolean(properties.getProperty("UseNewSpawning"));
            NoGreenGrassSides = !Boolean.parseBoolean(properties.getProperty("BetaGreenGrassSides"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
    }
    
    public void load(){
        Block.grass.toptex = ModLoader.addOverride("/terrain.png", "/nbx/grasstop.png");
        Block.grass.sidetex = ModLoader.addOverride("/terrain.png", "/nbx/grassside.png");
        Block.leaves.fasttex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfast.png");
        Block.leaves.fancytex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfancy.png");
        ModLoader.AddLocalization("nbxlite.genInfdev", "Generator: Infdev");
        ModLoader.AddLocalization("nbxlite.genAlpha", "Generator: Alpha");
        ModLoader.AddLocalization("nbxlite.genBeta", "Generator: Beta");
        ModLoader.AddLocalization("nbxlite.genRelease", "Generator: Release");
        ModLoader.AddLocalization("nbxlite.featuresHalloween", "Features: Alpha 1.2.0");
        ModLoader.AddLocalization("nbxlite.featuresBeta12", "Features: Beta 1.2");
        ModLoader.AddLocalization("nbxlite.featuresBeta14", "Features: Beta 1.4");
        ModLoader.AddLocalization("nbxlite.featuresBeta173", "Features: Beta 1.7.3");
        ModLoader.AddLocalization("nbxlite.featuresBeta181", "Features: Beta 1.8.1");
        ModLoader.AddLocalization("nbxlite.features10", "Features: 1.0");
        ModLoader.AddLocalization("nbxlite.features11", "Features: 1.1");
        ModLoader.AddLocalization("nbxlite.themeNormal", "Theme: Normal");
        ModLoader.AddLocalization("nbxlite.themeHell", "Theme: Hell");
        ModLoader.AddLocalization("nbxlite.themeWoods", "Theme: Woods");
        ModLoader.AddLocalization("nbxlite.themeParadise", "Theme: Paradise");
        ModLoader.AddLocalization("nbxlite.descriptionGenInfdev", "No biomes, large trees");
        ModLoader.AddLocalization("nbxlite.descriptionGenAlpha", "No biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenBeta", "Small biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenRelease", "Large biomes, villages");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesHalloween", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta12", "Lakes, special trees");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta14", "Sandstone");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta173", "Tall grass, weather");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta181", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures10", "Snow, mushrooms, dark swamps");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures11", "Snow in taiga, beaches, hills");
        ModLoader.AddLocalization("nbxlite.descriptionThemeNormal", "Blue sky, green grass");
        ModLoader.AddLocalization("nbxlite.descriptionThemeHell", "Dark world with lava oceans");
        ModLoader.AddLocalization("nbxlite.descriptionThemeWoods", "Cloudy sky, many trees");
        ModLoader.AddLocalization("nbxlite.descriptionThemeParadise", "Eternal day, large beaches");
//         ModLoader.RegisterKey(this, this.KeySpawn, false);
//         ModLoader.RegisterKey(this, this.KeySpawn2, false);
//         ModLoader.AddLocalization("key_spawn", "Green grass sides");
//         ModLoader.AddLocalization("key_spawn2", "Switch generator");
    }

    public String getVersion(){
        return "1.1.0";
    }

    public void HandlePacket(Packet230ModLoader packet)
    {
        switch(packet.packetType)
        {
            case 0:
            {
                Generator=packet.dataInt[0];
                if (packet.dataInt[0]==0){
                    MapTheme=packet.dataInt[2];
                    ModLoader.getMinecraftInstance().theWorld.setWorldTheme();
                    if (packet.dataInt[3]==1){
                        SnowCovered=true;
                    }else{
                        SnowCovered=false;
                    }
                }
                MapFeatures=packet.dataInt[1];
                if (packet.dataInt[0]==0){
                    mod_noBiomesX.SunriseEffect=false;
                }else{
                    mod_noBiomesX.SunriseEffect=true;
                }
                if (packet.dataInt[0]==2 && packet.dataInt[1]!=0){
                    mod_noBiomesX.SunriseAtNorth=false;
                }else{
                    mod_noBiomesX.SunriseAtNorth=true;
                }
                if (packet.dataInt[0]==2){
                    mod_noBiomesX.LowHangingClouds=false;
                    mod_noBiomesX.ClassicLight=false;
                    mod_noBiomesX.VoidFog=true;
                    mod_noBiomesX.MobSpawning=2;
                }else{
                    mod_noBiomesX.LowHangingClouds=true;
                    mod_noBiomesX.ClassicLight=true;
                    mod_noBiomesX.VoidFog=false;
                    mod_noBiomesX.MobSpawning=1;
                }
                if (packet.dataInt[0]==1 && packet.dataInt[1]<=2){
                    mod_noBiomesX.GreenGrassSides=true;
                }else{
                    mod_noBiomesX.GreenGrassSides=false;
                }
                if (packet.dataInt[4]==1){
                    UseNewSpawning=true;
                }else{
                    UseNewSpawning=false;
                }
            }
        }
    }

    public void RequestGeneratorInfo()
    {
        Packet230ModLoader packet = new Packet230ModLoader();
        packet.packetType = 1;
        ModLoaderMp.SendPacket(this,packet);
    }
    
 /*   public void KeyboardEvent(KeyBinding keybinding){
        if (keybinding==KeySpawn){
            if (Generator!=0){
                GreenGrassSides=!GreenGrassSides;
                ModLoader.getMinecraftInstance().renderGlobal.loadRenderers();
            }
        }else{
            Generator++;
            if (Generator>=3){
                Generator=0;
            }
            ModLoader.getMinecraftInstance().renderGlobal.loadRenderers();
        }
    }*/

//     public KeyBinding KeySpawn = new KeyBinding("key_spawn", 34);
//     public KeyBinding KeySpawn2 = new KeyBinding("key_spawn2", 35);
    public static int Generator = 2; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean GenerateLapis = true;
    public static boolean SunriseEffect = true;
    public static boolean SnowCovered = false;
    public static boolean LowHangingClouds = false;
    public static boolean ClassicLight=true;
    public static int LightTintRed = 255;
    public static int LightTintGreen = 255;
    public static int LightTintBlue = 255;
    public static boolean VoidFog=false;
    public static boolean GreenGrassSides=false;
    public static boolean NoGreenGrassSides=false;
    public static boolean InfdevCaves=false;
    public static boolean OpaqueFlatClouds=false;
    public static boolean SunriseAtNorth=false;
    public static boolean LeavesDecay=true;
    public static int MobSpawning=0; //0 - alpha; 1 - beta; 2 - 1.0
    public static int SkyColor = 0;
    public static int MapTheme = 0;  //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    public static int MapFeatures;   //for alpha: 0 - alpha; 1 - infdev; for beta: 0 - halloween; 1 - beta 1.2; 2 - beta 1.4; 3 - beta 1.7.3; for release: 0 - Beta 1.8; 1 - 1.0; 2 - 1.1
    public static int DefaultGenerator;
    public static int DefaultFeatures;
    public static int DefaultTheme;
    public static boolean UseNewSpawning;
}