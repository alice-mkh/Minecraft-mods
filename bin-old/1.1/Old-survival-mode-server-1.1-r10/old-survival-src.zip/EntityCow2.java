package net.minecraft.src;

import java.util.Random;

public class EntityCow2 extends EntityCow
{
    public EntityCow2(World world)
    {
        super(world);
    }

    protected int getDropItemId()
    {
        return Item.leather.shiftedIndex;
    }

    protected void dropFewItems(boolean flag, int i)
    {
        int j = rand.nextInt(3) + rand.nextInt(1 + i);
        for (int k = 0; k < j; k++)
        {
            dropItem(Item.leather.shiftedIndex, 1);
        }
        if (!mod_OldSurvivalMode.OldDrops){
            j = rand.nextInt(3) + 1 + rand.nextInt(1 + i);
            for (int l = 0; l < j; l++)
            {
                if (isBurning())
                {
                    dropItem(Item.beefCooked.shiftedIndex, 1);
                }
                else
                {
                    dropItem(Item.beefRaw.shiftedIndex, 1);
                }
            }
        }
    }
}
