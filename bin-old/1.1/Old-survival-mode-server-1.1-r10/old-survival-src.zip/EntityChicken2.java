package net.minecraft.src;

import java.util.Random;

public class EntityChicken2 extends EntityChicken
{
    public EntityChicken2(World world)
    {
        super(world);
    }

    protected int getDropItemId()
    {
        return Item.feather.shiftedIndex;
    }

    protected void dropFewItems(boolean flag, int i)
    {
        int j = rand.nextInt(3) + rand.nextInt(1 + i);
        for (int k = 0; k < j; k++)
        {
            dropItem(Item.feather.shiftedIndex, 1);
        }
        if (!mod_OldSurvivalMode.OldDrops){
            if (isBurning())
            {
                dropItem(Item.chickenCooked.shiftedIndex, 1);
            }
            else
            {
                dropItem(Item.chickenRaw.shiftedIndex, 1);
            }
        }
    }
}
