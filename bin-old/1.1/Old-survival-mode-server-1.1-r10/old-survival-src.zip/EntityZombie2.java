package net.minecraft.src;

import java.util.Random;

public class EntityZombie2 extends EntityZombie
{
    public EntityZombie2(World world)
    {
        super(world);
    }

    protected int getDropItemId()
    {
        if (!mod_OldSurvivalMode.OldDrops){
            return Item.rottenFlesh.shiftedIndex;
        }else{
            return Item.feather.shiftedIndex;
        }
    }
}
