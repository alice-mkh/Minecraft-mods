package net.minecraft.src;

import java.util.List;

public class ChunkProviderGenerate
    implements IChunkProvider
{
    public ChunkProviderGenerateInfdev infdevGen;
    public ChunkProviderGenerateOldInfdev oldInfdevGen;
    public ChunkProviderGenerateAlpha alphaGen;
    public ChunkProviderGenerateBeta betaGen;
    public ChunkProviderGenerateRelease releaseGen;

    public ChunkProviderGenerate(World world, long l, boolean flag)
    {
        infdevGen = new ChunkProviderGenerateInfdev(world, l, flag);
        oldInfdevGen = new ChunkProviderGenerateOldInfdev(world, l, flag);
        alphaGen = new ChunkProviderGenerateAlpha(world, l, flag);
        betaGen = new ChunkProviderGenerateBeta(world, l, flag);
        releaseGen = new ChunkProviderGenerateRelease(world, l, flag);
    }

    public Chunk loadChunk(int i, int j)
    {
        return provideChunk(i, j);
    }

    public Chunk provideChunk(int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                return alphaGen.provideChunk(i, j);
            }else if (mod_noBiomesX.MapFeatures==1){
                return infdevGen.provideChunk(i, j);
            }else{
                return oldInfdevGen.provideChunk(i, j);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.provideChunk(i, j);
        } else
        {
            return releaseGen.provideChunk(i, j);
        }
    }

    public boolean chunkExists(int i, int j)
    {
        return true;
    }

    public void populate(IChunkProvider ichunkprovider, int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                alphaGen.populate(ichunkprovider, i, j);
            }else if (mod_noBiomesX.MapFeatures==1){
                infdevGen.populate(ichunkprovider, i, j);
            }else{
                oldInfdevGen.populate(ichunkprovider, i, j);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            betaGen.populate(ichunkprovider, i, j);
        } else
        {
            releaseGen.populate(ichunkprovider, i, j);
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unload100OldestChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public String makeString()
    {
        return "RandomLevelSource";
    }

    public List func_40377_a(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        return releaseGen.func_40377_a_release(enumcreaturetype,i,j,k);
    }

    public ChunkPosition func_40376_a(World world, String s, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==0)
        {
            if (mod_noBiomesX.MapFeatures==0){
                return alphaGen.func_40376_a(world, s, i, j, k);
            }else if (mod_noBiomesX.MapFeatures==1){
                return infdevGen.func_40376_a(world, s, i, j, k);
            }else{
                return oldInfdevGen.func_40376_a(world, s, i, j, k);
            }
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.func_40376_a(world, s, i, j, k);
        } else
        {
            return releaseGen.func_40376_a(world, s, i, j, k);
        }
    }
}
