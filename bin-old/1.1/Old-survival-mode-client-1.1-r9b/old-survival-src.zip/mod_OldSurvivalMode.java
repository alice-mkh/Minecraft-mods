package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_OldSurvivalMode extends BaseMod{
    public String getVersion(){
        return "1.1";
    }

    public mod_OldSurvivalMode(){
        OldSurvivalModeProperties oldsurvivalmodeproperties = new OldSurvivalModeProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                oldsurvivalmodeproperties.setProperty("AnimalsFleeWhenDamaged", Boolean.toString(false));
                oldsurvivalmodeproperties.setProperty("DisableFoodStacking", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("InstantBow", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("InstantFood", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("DisableHunger", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("DisableXP", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("OldCombatSystem", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("OldArmor", Boolean.toString(true));
                oldsurvivalmodeproperties.store(fileoutputstream, "Survival mode config");

                fileoutputstream.close();
            }
            oldsurvivalmodeproperties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString()));
            DisableXP = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableXP"));
            DisableHunger = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableHunger"));
            InstantFood = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantFood"));
            InstantBow = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantBow"));
            DisableFoodStacking = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableFoodStacking"));
            AnimalsFlee = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("AnimalsFleeWhenDamaged"));
            OldCombatSystem = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("OldCombatSystem"));
            OldArmor = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("OldArmor"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
        ModLoader.SetInGameHook(this, true, true);
        SetSwordDamage(OldCombatSystem);
        SetArmorDamage(OldArmor);
    }
    
    public void SetSwordDamage(boolean b){
        try{
            if (b){
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordDiamond, "weaponDamage", 4 + 3 * 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordSteel, "weaponDamage", 4 + 2 * 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordStone, "weaponDamage", 4 + 1 * 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordWood, "weaponDamage", 4 + 0 * 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordGold, "weaponDamage", 4 + 0 * 2);
            }else{
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordDiamond, "weaponDamage", 7);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordSteel, "weaponDamage", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordStone, "weaponDamage", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordWood, "weaponDamage", 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordGold, "weaponDamage", 4);
            }
        }catch(Exception exception){
            System.out.println("WTF?");
        }
    }
    
    public void SetArmorDamage(boolean b){
        try{
            if (b){
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "maxdamage", 33 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "maxdamage", 33 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "maxdamage", 33 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "maxdamage", 33 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetDiamond, "maxdamage", 33 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "maxdamage", 48 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "maxdamage", 48 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "maxdamage", 48 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "maxdamage", 48 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateDiamond, "maxdamage", 48 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "maxdamage", 45 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "maxdamage", 45 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "maxdamage", 45 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "maxdamage", 45 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsDiamond, "maxdamage", 45 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "maxdamage", 39 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "maxdamage", 39 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "maxdamage", 39 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "maxdamage", 39 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsDiamond, "maxdamage", 39 << 3);
            }else{
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "damageReduceAmount", 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "maxdamage", 55);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "maxdamage", 165);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "maxdamage", 165);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "maxdamage", 77);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetDiamond, "maxdamage", 363);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "maxdamage", 80);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "maxdamage", 240);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "maxdamage", 240);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "maxdamage", 112);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateDiamond, "maxdamage", 528);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "maxdamage", 75);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "maxdamage", 225);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "maxdamage", 225);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "maxdamage", 105);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsDiamond, "maxdamage", 495);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "maxdamage", 65);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "maxdamage", 195);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "maxdamage", 195);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "maxdamage", 91);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsDiamond, "maxdamage", 429);
            }
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetDiamond, "damageReduceAmount", 3);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateDiamond, "damageReduceAmount", 8);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsDiamond, "damageReduceAmount", 6);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsDiamond, "damageReduceAmount", 3);
        }catch(Exception exception){
            System.out.println("WTF?");
        }
    }

    public boolean OnTickInGame(float f, Minecraft minecraft){
/*
        for (int k = 0; k < minecraft.theWorld.loadedEntityList.size(); k++)
        {
            if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityAnimal && !AnimalsFlee){
                EntityAnimal entity = (EntityAnimal)minecraft.theWorld.loadedEntityList.get(k);
                entity.fleeingTick=0;
            }else if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityXPOrb && DisableXP){
                EntityXPOrb entity = (EntityXPOrb)minecraft.theWorld.loadedEntityList.get(k);
                entity.setEntityDead();
            }
        }
        return true;
*/
        if (AnimalsFlee){
            return true;
        }
        EntityAnimal entity;
        for (int k = 0; k < minecraft.theWorld.loadedEntityList.size(); k++)
        {
            if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityAnimal){
                entity = (EntityAnimal)minecraft.theWorld.loadedEntityList.get(k);
                entity.fleeingTick=0;
            }
        }
        return true;
    }

    public void load(){};

    public static boolean DisableXP;
    public static boolean DisableHunger;
    public static boolean InstantFood;
    public static boolean InstantBow;
    public static boolean DisableFoodStacking;
    public static boolean AnimalsFlee;
    public static boolean OldCombatSystem;
    public static boolean OldArmor= true;
}