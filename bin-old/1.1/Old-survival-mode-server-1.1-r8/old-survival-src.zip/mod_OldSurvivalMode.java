package net.minecraft.src;

import net.minecraft.server.MinecraftServer;
import java.io.*;

public class mod_OldSurvivalMode extends BaseModMp{
    public mod_OldSurvivalMode(){
        PropertyManager pmanager = new PropertyManager(new File("server.properties"));
        DisableXP = pmanager.getBooleanProperty("disable-xp", true);
        DisableHunger = pmanager.getBooleanProperty("disable-hunger", true);
        DisableFoodStacking = pmanager.getBooleanProperty("disable-food-stacking", true);
        InstantFood = pmanager.getBooleanProperty("instant-food", true);
        InstantBow = pmanager.getBooleanProperty("instant-bow", true);
        AnimalsFlee = pmanager.getBooleanProperty("animals-flee", false);
        ModLoader.SetInGameHook(this, true, true);
    }

    public void load(){}

    public String getVersion(){
        return "1.1.0";
    }

    public void OnTickInGame(MinecraftServer minecraft){
        for (int l = 0; l < minecraft.worldMngr.length; l++){
            for (int k = 0; k < minecraft.worldMngr[l].loadedEntityList.size(); k++)
            {
                if ((Entity)minecraft.worldMngr[l].loadedEntityList.get(k) instanceof EntityAnimal && !AnimalsFlee){
                    EntityAnimal entity = (EntityAnimal)minecraft.worldMngr[l].loadedEntityList.get(k);
                    entity.fleeingTick=0;
                }else if ((Entity)minecraft.worldMngr[l].loadedEntityList.get(k) instanceof EntityXPOrb && DisableXP){
                    EntityXPOrb entity = (EntityXPOrb)minecraft.worldMngr[l].loadedEntityList.get(k);
                    entity.setEntityDead();
                }
            }
        }
    }

    public boolean hasClientSide()
    {
        return false;
    }

    public static boolean AnimalsFlee = false;
    public static boolean DisableXP = true;
    public static boolean DisableHunger = true;
    public static boolean InstantFood = true;
    public static boolean DisableFoodStacking = true;
    public static boolean InstantBow = true;
}