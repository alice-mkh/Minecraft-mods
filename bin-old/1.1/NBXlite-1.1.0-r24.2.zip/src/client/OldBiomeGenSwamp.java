package net.minecraft.src;

public class OldBiomeGenSwamp extends OldBiomeGenBase
{

    public OldBiomeGenSwamp()
    {
    }
}
