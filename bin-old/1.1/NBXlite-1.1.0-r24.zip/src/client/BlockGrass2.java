package net.minecraft.src;

import java.util.Random;

public class BlockGrass2 extends BlockGrass
{
    public int toptex;
    public int sidetex;
    protected BlockGrass2(int i)
    {
        super(i);
    }

    public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        if (l == 1)
        {
            if (mod_noBiomesX.Generator==0){
                return toptex;
            }else{
                return 0;
            }
        }
        if (l == 0)
        {
            return 2;
        }
        Material material = iblockaccess.getBlockMaterial(i, j + 1, k);
        if (mod_noBiomesX.Generator==0 || (mod_noBiomesX.GreenGrassSides && !mod_noBiomesX.NoGreenGrassSides)){
            return material != Material.snow && material != Material.craftedSnow ? sidetex : 68;
        }else{
            return material != Material.snow && material != Material.craftedSnow ? 3 : 68;
        }
    }

    public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if (mod_noBiomesX.Generator==0){
            return 0xffffff;
        }else if (mod_noBiomesX.Generator==1){
            iblockaccess.getWorldChunkManager().oldFunc_4069_a(i, k, 1, 1);
            double d = iblockaccess.getWorldChunkManager().temperature[0];
            double d1 = iblockaccess.getWorldChunkManager().humidity[0];
            return ColorizerGrass.getGrassColor(d, d1);
        }else{
            if (mod_noBiomesX.MapFeatures==2){
                int l = 0;
                int i1 = 0;
                int j1 = 0;
                for (int k1 = -1; k1 <= 1; k1++)
                {
                    for (int l1 = -1; l1 <= 1; l1++)
                    {
                        int i2 = iblockaccess.getWorldChunkManager().getBiomeGenAt(i + l1, k + k1).getGrassColorAtCoords(iblockaccess, i + l1, j, k + k1);
                        l += (i2 & 0xff0000) >> 16;
                        i1 += (i2 & 0xff00) >> 8;
                        j1 += i2 & 0xff;
                    }
                }
                return (l / 9 & 0xff) << 16 | (i1 / 9 & 0xff) << 8 | j1 / 9 & 0xff;
            }else{
                return iblockaccess.getWorldChunkManager().getBiomeGenAt(i, k).getGrassColorAtCoords(iblockaccess, i, j, k);
            }
        }
    }
}
