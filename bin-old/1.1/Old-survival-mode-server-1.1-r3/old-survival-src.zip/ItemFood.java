package net.minecraft.src;

import java.util.Random;

public class ItemFood extends Item
{
    public final int field_35427_a = 32;
    private final int healAmount;
    private final float saturationFactor;
    private final boolean isWolfsFavoriteMeat;
    private boolean alwaysEdible;
    private int potionId;
    private int potionDuration;
    private int potionAmplifier;
    private float potionEffectProbability;

    public ItemFood(int i, int j, float f, boolean flag)
    {
        super(i);
        healAmount = j;
        isWolfsFavoriteMeat = flag;
        saturationFactor = f;
        if (this.shiftedIndex==Item.cookie.shiftedIndex || this.shiftedIndex==Item.melon.shiftedIndex){
            maxStackSize = 8;
        }else{
            maxStackSize = 1;
        }
    }

    public ItemFood(int i, int j, boolean flag)
    {
        this(i, j, 0.6F, flag);
    }

    public ItemStack onFoodEaten(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        itemstack.stackSize--;
        world.playSoundAtEntity(entityplayer, "random.burp", 0.5F, world.rand.nextFloat() * 0.1F + 0.9F);
        if(!world.singleplayerWorld){
            if (this.shiftedIndex==Item.appleGold.shiftedIndex){
                entityplayer.heal(20);
            }else{
                entityplayer.heal(healAmount);
            }
        }
        return itemstack;
    }

    public int getMaxItemUseDuration(ItemStack itemstack)
    {
        return 32;
    }

    public EnumAction getAction(ItemStack itemstack)
    {
        return EnumAction.eat;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        itemstack.stackSize--;
        onFoodEaten(itemstack, world, entityplayer);
        if (this.shiftedIndex==Item.bowlSoup.shiftedIndex){
            return new ItemStack(Item.bowlEmpty);
        }
        return itemstack;
    }

    public int getHealAmount()
    {
        return healAmount;
    }

    public float getSaturationFactor()
    {
        return saturationFactor;
    }

    public boolean getIsWolfsFavoriteMeat()
    {
        return isWolfsFavoriteMeat;
    }

    public ItemFood setPotionEffect(int i, int j, int k, float f)
    {
        potionId = i;
        potionDuration = j;
        potionAmplifier = k;
        potionEffectProbability = f;
        return this;
    }

    public ItemFood setAlwaysEdible()
    {
        alwaysEdible = true;
        return this;
    }

    public Item setItemName(String s)
    {
        return super.setItemName(s);
    }
}
