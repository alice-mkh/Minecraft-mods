package net.minecraft.src;

import java.util.List;

public class OldBiomeGenHell extends OldBiomeGenBase
{
    public OldBiomeGenHell()
    {
        spawnableMonsterList.clear();
        spawnableCreatureList.clear();
        spawnableWaterCreatureList.clear();
        spawnableMonsterList.add(new SpawnListEntryBeta(net.minecraft.src.EntityGhast.class, 10));
        spawnableMonsterList.add(new SpawnListEntryBeta(net.minecraft.src.EntityPigZombie.class, 10));
    }
}
