package net.minecraft.src;

public class SSPOptions{
    public boolean getDebugSeed(){
        return true;
    }

    public boolean getShareButton(){
        return true;
    }

    public boolean getSMPButton(){
        return true;
    }
}