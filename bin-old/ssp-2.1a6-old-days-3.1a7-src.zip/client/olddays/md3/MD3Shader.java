package net.minecraft.src;

public class MD3Shader{
}