package net.minecraft.src;

public class MD3Frame{
    Vec3 min;
    Vec3 max;
    Vec3 origin;
    Float radius;
    String name;
}