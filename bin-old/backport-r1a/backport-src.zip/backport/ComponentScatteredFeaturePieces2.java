package net.minecraft.src.backport;

import net.minecraft.src.*;

class ComponentScatteredFeaturePieces2
{
}
