package net.minecraft.src;

import java.util.Random;

public class BlockTallGrass2 extends BlockTallGrass
{
    protected BlockTallGrass2(int i, int j)
    {
        super(i, j);
    }

    public int colorMultiplier(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getBlockMetadata(i, j, k);
        if (l == 0)
        {
            return 0xffffff;
        }
        else
        if(mod_noBiomesX.Generator==0)
        {
            return 0x5fff3f;
        } else if(mod_noBiomesX.Generator==1)
        {
            iblockaccess.getWorldChunkManager().oldFunc_4069_a(i, k, 1, 1);
            double d = iblockaccess.getWorldChunkManager().temperature[0];
            double d1 = iblockaccess.getWorldChunkManager().humidity[0];
            return ColorizerGrass.getGrassColor(d, d1);
        }else{
            return iblockaccess.getWorldChunkManager().getBiomeGenAt(i, k).getGrassColorAtCoords(iblockaccess, i, j, k);
        }
    }
}
