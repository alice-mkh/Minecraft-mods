package net.minecraft.src.nbxlite.indev;

import java.util.Random;
import net.minecraft.src.*;

public class IndevBlockFlower extends BlockFlower
{
    protected IndevBlockFlower(int i, int j)
    {
        super(i, j);
    }

    public boolean e(g world, int i, int j, int k)
    {
        return true;
    }
}
