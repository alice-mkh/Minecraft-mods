package net.minecraft.src;

import net.minecraft.client.Minecraft;
import java.io.*;
import java.util.*;
import net.minecraft.src.nbxlite.*;
import net.minecraft.src.nbxlite.blocks.*;

public class mod_noBiomesX extends BaseModMp{
    public mod_noBiomesX(){
        NBXliteProperties properties = new NBXliteProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                properties.setProperty("UseNewSpawning",Boolean.toString(false));
                properties.setProperty("BetaGreenGrassSides",Boolean.toString(true));
                properties.store(fileoutputstream,"NBXlite properties");
                fileoutputstream.close();
            }
            properties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString()));
            UseNewSpawning = Boolean.parseBoolean(properties.getProperty("UseNewSpawning"));
            NoGreenGrassSides = !Boolean.parseBoolean(properties.getProperty("BetaGreenGrassSides"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
    }

    public void load(){
        ModLoader.AddLocalization("nbxlite.genInfdev", "Generator: Infdev");
        ModLoader.AddLocalization("nbxlite.genAlpha", "Generator: Alpha");
        ModLoader.AddLocalization("nbxlite.genBeta", "Generator: Beta");
        ModLoader.AddLocalization("nbxlite.genRelease", "Generator: Release");
        ModLoader.AddLocalization("nbxlite.featuresHalloween", "Features: Alpha 1.2.0");
        ModLoader.AddLocalization("nbxlite.featuresBeta12", "Features: Beta 1.2");
        ModLoader.AddLocalization("nbxlite.featuresBeta14", "Features: Beta 1.4");
        ModLoader.AddLocalization("nbxlite.featuresBeta15", "Features: Beta 1.5");
        ModLoader.AddLocalization("nbxlite.featuresBeta173", "Features: Beta 1.7.3");
        ModLoader.AddLocalization("nbxlite.featuresBeta181", "Features: Beta 1.8.1");
        ModLoader.AddLocalization("nbxlite.features10", "Features: 1.0");
        ModLoader.AddLocalization("nbxlite.features11", "Features: 1.1");
        ModLoader.AddLocalization("nbxlite.themeNormal", "Theme: Normal");
        ModLoader.AddLocalization("nbxlite.themeHell", "Theme: Hell");
        ModLoader.AddLocalization("nbxlite.themeWoods", "Theme: Woods");
        ModLoader.AddLocalization("nbxlite.themeParadise", "Theme: Paradise");
        ModLoader.AddLocalization("nbxlite.descriptionGenInfdev", "No biomes, large trees");
        ModLoader.AddLocalization("nbxlite.descriptionGenAlpha", "No biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenBeta", "Small biomes, low clouds");
        ModLoader.AddLocalization("nbxlite.descriptionGenRelease", "Large biomes, villages");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesHalloween", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta12", "Lakes, special trees");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta14", "Sandstone");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta15", "Weather");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta173", "Tall grass");
        ModLoader.AddLocalization("nbxlite.descriptionFeaturesBeta181", "No special features");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures10", "Snow, mushrooms, dark swamps");
        ModLoader.AddLocalization("nbxlite.descriptionFeatures11", "Snow in taiga, beaches, hills");
        ModLoader.AddLocalization("nbxlite.descriptionThemeNormal", "Blue sky, green grass");
        ModLoader.AddLocalization("nbxlite.descriptionThemeHell", "Dark world with lava oceans");
        ModLoader.AddLocalization("nbxlite.descriptionThemeWoods", "Cloudy sky, many trees");
        ModLoader.AddLocalization("nbxlite.descriptionThemeParadise", "Eternal day, large beaches");
        ModLoader.AddLocalization("nbxlite.convert", "Select world settings");
        ModLoader.AddLocalization("nbxlite.continue", "Continue");
//         ModLoader.RegisterKey(this, this.KeySpawn2, false);
//         ModLoader.AddLocalization("key_spawn2", "Toggle sky dimension");
        ReplaceBlocks();
//         ReplaceHoes();
    }

    private static void ReplaceBlocks(){
        try{
            Block.grass.toptex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/grasstop.png");
            Block.grass.sidetex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/grassside.png");
/*
            Block.blocksList[2] = null;
            BlockGrass2 grass2 = (BlockGrass2)(new BlockGrass2(2)).setHardness(0.6F).setStepSound(Block.soundGrassFootstep).setBlockName("grass");
            Block.blocksList[2] = grass2;
            grass2.toptex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/grasstop.png");
            grass2.sidetex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/grassside.png");
            Block.blocksList[18] = null;
            BlockLeaves2 leaves2 = (BlockLeaves2)(new BlockLeaves2(18, 52)).setHardness(0.2F).setLightOpacity(1).setStepSound(Block.soundGrassFootstep).setBlockName("leaves").setRequiresSelfNotify();
            Block.blocksList[18] = leaves2;
            leaves2.fasttex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/leavesfast.png");
            leaves2.fancytex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/leavesfancy.png");
*/
            Block.leaves.fasttex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/leavesfast.png");
            Block.leaves.fancytex = ModLoader.addOverride("/terrain.png", "/nbxlite/textures/leavesfancy.png");
            Block.blocksList[31] = null;
            BlockTallGrass2 tallgrass2 = (BlockTallGrass2)(new BlockTallGrass2(31, 39)).setHardness(0.0F).setStepSound(Block.soundGrassFootstep).setBlockName("tallgrass");
            Block.blocksList[31] = tallgrass2;
            Block.blocksList[106] = null;
            BlockVine2 vine2 = (BlockVine2)(new BlockVine2(106)).setHardness(0.2F).setStepSound(Block.soundGrassFootstep).setBlockName("vine").setRequiresSelfNotify();
            Block.blocksList[106] = vine2;
        }catch (Exception exception){
            System.out.println(exception);
        }
    }
/*
    private static void ReplaceHoes(){
        try{
            Item.itemsList[34] = null;
            ItemHoe2 hoeWood2 = (ItemHoe2)(new ItemHoe2(34, EnumToolMaterial.WOOD)).setIconCoord(0, 8).setItemName("hoeWood");
            Item.itemsList[34] = hoeWood2;

//             hoeWood = (new ItemHoe(34, EnumToolMaterial.WOOD)).setIconCoord(0, 8).setItemName("hoeWood");
//             hoeStone = (new ItemHoe(35, EnumToolMaterial.STONE)).setIconCoord(1, 8).setItemName("hoeStone");
//             hoeSteel = (new ItemHoe(36, EnumToolMaterial.IRON)).setIconCoord(2, 8).setItemName("hoeIron");
//             hoeDiamond = (new ItemHoe(37, EnumToolMaterial.EMERALD)).setIconCoord(3, 8).setItemName("hoeDiamond");
//             hoeGold = (new ItemHoe(38, EnumToolMaterial.GOLD)).setIconCoord(4, 8).setItemName("hoeGold");
        }catch (Exception exception){
            System.out.println(exception);
        }
    }
*/
    public String getVersion(){
        return "1.1.0";
    }

    public void HandlePacket(Packet230ModLoader packet)
    {
        switch(packet.packetType){
            case 0:{
                Generator=packet.dataInt[0];
                MapFeatures=packet.dataInt[1];
                if (packet.dataInt[0]==0){
                    MapTheme=packet.dataInt[2];
                    ModLoader.getMinecraftInstance().theWorld.setWorldTheme();
                    if (packet.dataInt[3]==1){
                        SnowCovered=true;
                    }else{
                        SnowCovered=false;
                    }
                }
                if (packet.dataInt[0]==0){
                    SunriseEffect=false;
                }else{
                    SunriseEffect=true;
                }
                if (packet.dataInt[0]==2 && packet.dataInt[1]!=0){
                    SunriseAtNorth=false;
                }else{
                    SunriseAtNorth=true;
                }
                if (packet.dataInt[0]==2){
                    LowHangingClouds=false;
                    ClassicLight=false;
                    VoidFog=true;
                }else{
                    LowHangingClouds=true;
                    ClassicLight=true;
                    VoidFog=false;
                }
                if (packet.dataInt[0]==1 && packet.dataInt[1]<=2 && !NoGreenGrassSides){
                    GreenGrassSides=true;
                }else{
                    GreenGrassSides=false;
                }
                if (packet.dataInt[0]==0 && packet.dataInt[1]==1){
                    LeavesDecay=false;
                }else{
                    LeavesDecay=true;
                }
            }
        }
    }

    public void RequestGeneratorInfo()
    {
        Packet230ModLoader packet = new Packet230ModLoader();
        packet.packetType = 1;
        ModLoaderMp.SendPacket(this,packet);
    }

    public void AddRenderer(Map map){   
        map.put(net.minecraft.src.EntityGhast.class, new RenderGhast2());//Disable ghast shading with classic light
    }

    public static void SetGenerator(World world, int gen, int features, int theme, boolean snow){
        Generator=gen;
        MapFeatures=features;
        MobSpawning=gen;
        if (gen==2){
            if (features==0){
                BiomeGenBase.swampland.biomeDecorator.waterlilyPerChunk = 0;
                BiomeGenBase.ocean.maxHeight = 0.5F;
            }else{
                BiomeGenBase.swampland.biomeDecorator.waterlilyPerChunk = 4;
                BiomeGenBase.ocean.maxHeight = 0.4F;
            }
            if (features==2){
                BiomeGenBase.taiga.temperature = 0.05F;
                BiomeGenBase.extremeHills.maxHeight = 1.3F;
            }else{
                BiomeGenBase.taiga.temperature = 0.3F;
                BiomeGenBase.extremeHills.maxHeight = 1.8F;
            }
            if (features==2){
                BiomeGenBase.swampland.waterColorMultiplier = 0xe0ffae;
            }else if (features==1){
                BiomeGenBase.swampland.waterColorMultiplier = 0xe0ff70;
            }else{
                BiomeGenBase.swampland.waterColorMultiplier = 0xffffff;
            }
        }else{
            BiomeGenBase.swampland.waterColorMultiplier = 0xffffff;
        }
        if (gen==0){
            MapTheme=theme;
            world.setWorldTheme();
            SunriseEffect=false;
            world.turnOnOldSpawners();
        }else{
            SunriseEffect=true;
        }
        if (gen==0 && (theme==0||theme==2)){
            SnowCovered=snow;
        }else{
            SnowCovered=false;
        }
        if (gen==2 && features!=0){
            SunriseAtNorth=false;
        }else{
            SunriseAtNorth=true;
        }
        if (gen==2){
            LowHangingClouds=false;
            ClassicLight=false;
            VoidFog=true;
        }else{
            LowHangingClouds=true;
            ClassicLight=true;
            VoidFog=false;
        }
        if (gen==1 && features<=2 && !NoGreenGrassSides){
            GreenGrassSides=true;
        }else{
            GreenGrassSides=false;
        }
        if (gen==0 && features==1){
            LeavesDecay=false;
        }else{
            LeavesDecay=true;
        }
    }
/*
    public void KeyboardEvent(KeyBinding keybinding){
        World world = ModLoader.getMinecraftInstance().theWorld;
        if (!world.multiplayerWorld){
            if (Generator!=0){
                world.worldInfo.setIsRaining(!world.worldInfo.getIsRaining());
            }else{
                SnowCovered=!SnowCovered;
            }
        }
    }
*/
//     public KeyBinding KeySpawn2 = new KeyBinding("key_spawn2", 35);
    public static int Generator = 2; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean GenerateLapis = true;
    public static boolean SunriseEffect = true;
    public static boolean SnowCovered = false;
    public static boolean LowHangingClouds = false;
    public static boolean ClassicLight=true;
    public static boolean VoidFog=false;
    public static boolean GreenGrassSides=false;
    public static boolean NoGreenGrassSides=false;
    public static boolean OpaqueFlatClouds=false;
    public static boolean SunriseAtNorth=false;
    public static boolean LeavesDecay=true;
    public static boolean OldSkyDimension=false;
    public static int MobSpawning=0; //0 - alpha; 1 - beta; 2 - 1.0
    public static int MapTheme = 0;  //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    //Alpha: 0 - alpha; 1 - infdev; 2 - old infdev;
    //Beta: 0 - halloween; 1 - beta 1.2; 2 - beta 1.4; 3 - beta 1.5; 4 - beta 1.7.3;
    //Release: 0 - Beta 1.8; 1 - 1.0; 2 - 1.1;
    public static int MapFeatures=2;
    public static boolean UseNewSpawning = false;
//     public static float Strafe = 0F;
//     public static float Lol = 0F;
}