package net.minecraft.src;

import java.util.List;

public class ChunkProviderGenerate
    implements IChunkProvider
{
    public ChunkProviderGenerateAlpha alphaGen;
    public ChunkProviderGenerateBeta betaGen;
    public ChunkProviderGenerate18 Gen18;
    public ChunkProviderGenerate10 Gen10;
    public ChunkProviderGenerate11 Gen11;

    public ChunkProviderGenerate(World world, long l, boolean flag)
    {
        alphaGen = new ChunkProviderGenerateAlpha(world, l, flag);
        betaGen = new ChunkProviderGenerateBeta(world, l, flag);
        Gen18 = new ChunkProviderGenerate18(world, l, flag);
        Gen10 = new ChunkProviderGenerate10(world, l, flag);
        Gen11 = new ChunkProviderGenerate11(world, l, flag);
    }

    public Chunk loadChunk(int i, int j)
    {
        return provideChunk(i, j);
    }

    public Chunk provideChunk(int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            return alphaGen.provideChunk(i, j);
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.provideChunk(i, j);
        } else
        {
            if (mod_noBiomesX.MapFeatures==0){
                return Gen18.provideChunk(i, j);
            }else if (mod_noBiomesX.MapFeatures==1){
                return Gen10.provideChunk(i, j);
            }else{
                return Gen11.provideChunk(i, j);
            }
        }
    }

    public boolean chunkExists(int i, int j)
    {
        return true;
    }

    public void populate(IChunkProvider ichunkprovider, int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            alphaGen.populate(ichunkprovider, i, j);
        } else if(mod_noBiomesX.Generator==1)
        {
            betaGen.populate(ichunkprovider, i, j);
        } else
        {
            if (mod_noBiomesX.MapFeatures==0){
                Gen18.populate(ichunkprovider, i, j);
            }else if (mod_noBiomesX.MapFeatures==1){
                Gen10.populate(ichunkprovider, i, j);
            }else{
                Gen11.populate(ichunkprovider, i, j);
            }
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unload100OldestChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public List func_40181_a(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==2){
            if (mod_noBiomesX.MapFeatures==0){
                return Gen18.func_40377_a_18(enumcreaturetype,i,j,k);
            }else if (mod_noBiomesX.MapFeatures==1){
                return Gen10.func_40377_a_10(enumcreaturetype,i,j,k);
            }else{
                return Gen11.func_40377_a_11(enumcreaturetype,i,j,k);
            }
        }
        return null;
    }

    public ChunkPosition func_40182_a(World world, String s, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==0)
        {
            return alphaGen.func_40182_a(world, s, i, j, k);
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.func_40182_a(world, s, i, j, k);
        } else
        {
            if (mod_noBiomesX.MapFeatures==0){
                return Gen18.func_40182_a(world, s, i, j, k);
            }else if (mod_noBiomesX.MapFeatures==1){
                return Gen10.func_40182_a(world, s, i, j, k);
            }else{
                return Gen11.func_40182_a(world, s, i, j, k);
            }
        }
    }
}
