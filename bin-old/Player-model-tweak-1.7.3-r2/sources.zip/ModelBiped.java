// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

// Referenced classes of package net.minecraft.src:
//            ModelBase, ModelRenderer, MathHelper

public class ModelBiped extends ModelBase
{

    public ModelBiped()
    {
        this(0.0F);
    }

    public ModelBiped(float f)
    {
        this(f, 0.0F);
    }

    public static void applySettings(int i){

	if(!mod_playerModelTweak.Custom){
	    if(i==0){	//No Animation
		speed = 0F;
		speedSneak = 0F;
		legsX = 0F;
		legsXSneak = 0F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 0F;
		armsXSneak = 0F;
		armsZ = 0F;
		armsZSneak = 0F;
		headMode = 2;
		upDownAmplitude = 0F;
		armsMode = 1;
		itemInHand = false;
		useSwing = false;
	    }else if(i==1){	//Default
		speed = 1F;
		speedSneak = 1F;
		legsX = 1.4F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 1F;
		armsXSneak = 1.4F;
		armsZ = 0.05F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 0F;
		armsMode = 1;
		itemInHand = true;
		useSwing = true;
	    }else if(i==2){	//Indev, Infdev
		speed = 1F;
		speedSneak = 1F;
		legsX = 1.4F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 2.1F;
		armsXSneak = 1.4F;
		armsZ = 1F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 0F;
		armsMode = 1;
		itemInHand = false;
		useSwing = false;
	    }else if(i==3){	//Classic Multiplayer
		speed = 0.75F;
		speedSneak = 1F;
		legsX = 1.7F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 2.1F;
		armsXSneak = 1.4F;
		armsZ = 1F;
		armsZSneak = 0F;
		headMode = 3;
		upDownAmplitude = 2F;
		armsMode = 1;
		itemInHand = false;
		useSwing = false;
	    }else if(i==4){	//Classic Multiplayer
		speed = 0.75F;
		speedSneak = 1F;
		legsX = 1.7F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 2.1F;
		armsXSneak = 1.4F;
		armsZ = 1F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 2F;
		armsMode = 1;
		itemInHand = false;
		useSwing = false;
	    }else if(i==5){	//Skin test
		speed = 0.5F;
		speedSneak = 1F;
		legsX = 1.7F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 2.1F;
		armsXSneak = 1.4F;
		armsZ = 1F;
		armsZSneak = 0F;
		headMode = 3;
		upDownAmplitude = 2F;
		armsMode = 1;
		itemInHand = false;
		useSwing = false;
	    }else if(i==6){	//Zombie
		speed = 1F;
		speedSneak = 1F;
		legsX = 1.4F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 1F;
		armsXSneak = 1.4F;
		armsZ = 0.05F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 0F;
		armsMode = 2;
		itemInHand = false;
		useSwing = false;
	    }else if(i==7){	//Zombie from Survival test
		speed = 0.9F;
		speedSneak = 1F;
		legsX = 1.7F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 2.1F;
		armsXSneak = 1.4F;
		armsZ = 0F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 2F;
		armsMode = 2;
		itemInHand = false;
		useSwing = false;
	    }else{
		speed = 1F;
		speedSneak = 1F;
		legsX = 1.4F;
		legsXSneak = 1.4F;
		legsZ = 0F;
		legsZSneak = 0F;
		armsX = 1F;
		armsXSneak = 1.4F;
		armsZ = 0.05F;
		armsZSneak = 0F;
		headMode = 1;
		upDownAmplitude = 0F;
		armsMode = 1;
		itemInHand = true;
		useSwing = false;
	    }
	}else{
	    speed = mod_playerModelTweak.CustomSpeed;
	    speedSneak = mod_playerModelTweak.CustomSpeedSneak;
	    legsX = mod_playerModelTweak.CustomLegsX;
	    legsXSneak = mod_playerModelTweak.CustomLegsXSneak;
	    legsZ = mod_playerModelTweak.CustomLegsZ;
	    legsZSneak = mod_playerModelTweak.CustomLegsZSneak;
	    armsX = mod_playerModelTweak.CustomArmsX;
	    armsXSneak = mod_playerModelTweak.CustomArmsXSneak;
	    armsZ = mod_playerModelTweak.CustomArmsZ;
	    armsZSneak = mod_playerModelTweak.CustomArmsZSneak;
	    headMode = mod_playerModelTweak.CustomHeadMode;
	    upDownAmplitude = mod_playerModelTweak.CustomUpDownAmplitude;
	    armsMode = mod_playerModelTweak.CustomArmsMode;
	    itemInHand = mod_playerModelTweak.CustomItemInHand;
	    useSwing = mod_playerModelTweak.CustomUseSwing;
	}
    }

    public ModelBiped(float f, float f1)
    {
	applySettings(mod_playerModelTweak.Preset);
        field_1279_h = false;
        field_1278_i = false;
        isSneak = false;
        bipedCloak = new ModelRenderer(0, 0);
        bipedCloak.addBox(-5F, 0.0F, -1F, 10, 16, 1, f);
        bipedEars = new ModelRenderer(24, 0);
        bipedEars.addBox(-3F, -6F, -1F, 6, 6, 1, f);
        bipedHead = new ModelRenderer(0, 0);
        bipedHead.addBox(-4F, -8F, -4F, 8, 8, 8, f);
        bipedHead.setRotationPoint(0.0F, 0.0F + f1, 0.0F);
        bipedHeadwear = new ModelRenderer(32, 0);
        bipedHeadwear.addBox(-4F, -8F, -4F, 8, 8, 8, f + 0.5F);
        bipedHeadwear.setRotationPoint(0.0F, 0.0F + f1, 0.0F);
        bipedBody = new ModelRenderer(16, 16);
        bipedBody.addBox(-4F, 0.0F, -2F, 8, 12, 4, f);
        bipedBody.setRotationPoint(0.0F, 0.0F + f1, 0.0F);
        bipedRightArm = new ModelRenderer(40, 16);
        bipedRightArm.addBox(-3F, -2F, -2F, 4, 12, 4, f);
        bipedRightArm.setRotationPoint(-5F, 2.0F + f1, 0.0F);
        bipedLeftArm = new ModelRenderer(40, 16);
        bipedLeftArm.mirror = true;
        bipedLeftArm.addBox(-1F, -2F, -2F, 4, 12, 4, f);
        bipedLeftArm.setRotationPoint(5F, 2.0F + f1, 0.0F);
        bipedRightLeg = new ModelRenderer(0, 16);
        bipedRightLeg.addBox(-2F, 0.0F, -2F, 4, 12, 4, f);
        bipedRightLeg.setRotationPoint(-2F, 12F + f1, 0.0F);
        bipedLeftLeg = new ModelRenderer(0, 16);
        bipedLeftLeg.mirror = true;
        bipedLeftLeg.addBox(-2F, 0.0F, -2F, 4, 12, 4, f);
        bipedLeftLeg.setRotationPoint(2.0F, 12F + f1, 0.0F);
    }

    public void render(float f, float f1, float f2, float f3, float f4, float f5)
    {
        setRotationAngles(f, f1, f2, f3, f4, f5);
        bipedHead.render(f5);
        bipedBody.render(f5);
        bipedRightArm.render(f5);
        bipedLeftArm.render(f5);
        bipedRightLeg.render(f5);
        bipedLeftLeg.render(f5);
        bipedHeadwear.render(f5);
    }

    public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5){
        bipedHeadwear.rotateAngleY = bipedHead.rotateAngleY;
        bipedHeadwear.rotateAngleX = bipedHead.rotateAngleX;
        bipedHeadwear.rotateAngleZ = bipedHead.rotateAngleZ;
	bipedRightArm.rotateAngleX = MathHelper.cos(f * 0.6662F * speed + 3.141593F) * armsX * f1;
	bipedLeftArm.rotateAngleX = MathHelper.cos(f * 0.6662F * speed) * armsX * f1;
	bipedRightArm.rotateAngleZ = 0.0F * speed;
	bipedLeftArm.rotateAngleZ = 0.0F * speed;
	bipedRightLeg.rotateAngleY = 0.0F * speed;
	bipedLeftLeg.rotateAngleY = 0.0F * speed;
	if(armsMode==2){
	    float f6 = MathHelper.sin(onGround * 3.141593F);
	    float f7 = MathHelper.sin((1.0F - (1.0F - onGround) * (1.0F - onGround)) * 3.141593F);
	    bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
	    bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
	    bipedRightArm.rotateAngleX = -1.570796F ;
	    bipedLeftArm.rotateAngleX = -1.570796F;
	    bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
	    bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
	    bipedRightArm.rotateAngleX += MathHelper.sin(f2 * 0.067F) * 0.05F;
	    bipedLeftArm.rotateAngleX -= MathHelper.sin(f2 * 0.067F) * 0.05F;
	}

	if(itemInHand){
	    if(field_1279_h){
		bipedLeftArm.rotateAngleX = bipedLeftArm.rotateAngleX * 0.5F - 0.3141593F;
	    }
	    if(field_1278_i){
		bipedRightArm.rotateAngleX = bipedRightArm.rotateAngleX * 0.5F - 0.3141593F;
	    }
	}

        if(isRiding)
        {
            bipedRightArm.rotateAngleX += -0.6283185F;
            bipedLeftArm.rotateAngleX += -0.6283185F;
            bipedRightLeg.rotateAngleX = -1.256637F;
            bipedLeftLeg.rotateAngleX = -1.256637F;
            bipedRightLeg.rotateAngleY = 0.3141593F;
            bipedLeftLeg.rotateAngleY = -0.3141593F;
        }
        bipedRightArm.rotateAngleY = 0.0F;
        bipedLeftArm.rotateAngleY = 0.0F;

	if(useSwing){
	    if(onGround > -9990F)
	    {
		float f6 = onGround;
		bipedBody.rotateAngleY = MathHelper.sin(MathHelper.sqrt_float(f6) * 3.141593F * 2.0F) * 0.2F;
		bipedRightArm.rotationPointZ = MathHelper.sin(bipedBody.rotateAngleY) * 5F;
		bipedRightArm.rotationPointX = -MathHelper.cos(bipedBody.rotateAngleY) * 5F;
		bipedLeftArm.rotationPointZ = -MathHelper.sin(bipedBody.rotateAngleY) * 5F;
		bipedLeftArm.rotationPointX = MathHelper.cos(bipedBody.rotateAngleY) * 5F;
		bipedRightArm.rotateAngleY += bipedBody.rotateAngleY;
		bipedLeftArm.rotateAngleY += bipedBody.rotateAngleY;
		bipedLeftArm.rotateAngleX += bipedBody.rotateAngleY;
		f6 = 1.0F - onGround;
		f6 *= f6;
		f6 *= f6;
		f6 = 1.0F - f6;
		float f7 = MathHelper.sin(f6 * 3.141593F);
		float f8 = MathHelper.sin(onGround * 3.141593F) * -(bipedHead.rotateAngleX - 0.7F) * 0.75F;
		bipedRightArm.rotateAngleX -= (double)f7 * 1.2D + (double)f8;
		bipedRightArm.rotateAngleY += bipedBody.rotateAngleY * 2.0F;
		bipedRightArm.rotateAngleZ = MathHelper.sin(onGround * 3.141593F) * -0.4F;
	    }
	}

	    if(isSneak)
        {
            bipedBody.rotateAngleX = 0.5F;
            bipedRightLeg.rotateAngleX -= 0.0F;
            bipedLeftLeg.rotateAngleX -= 0.0F;
            bipedRightLeg.rotationPointZ = 4F;
            bipedLeftLeg.rotationPointZ = 4F;
            bipedRightLeg.rotationPointY = 9F;
            bipedLeftLeg.rotationPointY = 9F;
            bipedHead.rotationPointY = 1.0F;
	    bipedBody.rotationPointY = 0F;
	    bipedLeftArm.rotationPointY = 2F;
	    bipedRightArm.rotationPointY = 2F;
	    bipedLeftLeg.rotateAngleZ = (MathHelper.cos(f * 0.2812F * speed) - 1.0F) * legsZSneak * f1;
	    bipedRightLeg.rotateAngleZ = (MathHelper.cos(f * 0.2312F * speed) + 1.0F) * legsZSneak * f1;
	    bipedLeftArm.rotateAngleZ = (MathHelper.cos(f * 0.2812F * speed) - 1.0F) * armsZSneak * f1;
	    bipedRightArm.rotateAngleZ = (MathHelper.cos(f * 0.2312F * speed) + 1.0F) * armsZSneak * f1;
	    bipedRightArm.rotateAngleX = MathHelper.cos(f * 0.6662F * speedSneak + 3.141593F) * armsXSneak * f1 + 0.4F;
	    bipedLeftArm.rotateAngleX = MathHelper.cos(f * 0.6662F * speedSneak) * armsXSneak * f1 + 0.4F;
	    if(armsMode==2){
		float f6 = MathHelper.sin(onGround * 3.141593F);
		float f7 = MathHelper.sin((1.0F - (1.0F - onGround) * (1.0F - onGround)) * 3.141593F);
		bipedRightArm.rotateAngleZ = 0.0F;
		bipedLeftArm.rotateAngleZ = 0.0F;
		bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
		bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
		bipedRightArm.rotateAngleX = -1.570796F;
		bipedLeftArm.rotateAngleX = -1.570796F;
		bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
		bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
		bipedRightArm.rotateAngleZ += MathHelper.cos(f2 * 0.09F) * 0.05F + 0.05F;
		bipedLeftArm.rotateAngleZ -= MathHelper.cos(f2 * 0.09F) * 0.05F + 0.05F;
		bipedRightArm.rotateAngleX += MathHelper.sin(f2 * 0.067F) * 0.05F;
		bipedLeftArm.rotateAngleX -= MathHelper.sin(f2 * 0.067F) * 0.05F;
	    }
	    bipedRightLeg.rotateAngleX = MathHelper.cos(f * 0.6662F * speedSneak) * legsXSneak * f1;
	    bipedLeftLeg.rotateAngleX = MathHelper.cos(f * 0.6662F * speedSneak + 3.141593F) * legsXSneak * f1;
	    if(headMode==2){
		bipedHead.rotateAngleX = 0.5F;
		bipedHead.rotateAngleY = 0F;
		bipedHeadwear.rotateAngleX = 0.5F;
		bipedHeadwear.rotateAngleY = 0F;
	    }else if(headMode==3){
		bipedHead.rotateAngleX = 0.5F;
		bipedHead.rotateAngleY = 0F;
		bipedHeadwear.rotateAngleX = 0.5F;
		bipedHeadwear.rotateAngleY = 0F;
	    }else{
		bipedHead.rotateAngleY = f3 / 57.29578F;
		bipedHead.rotateAngleX = f4 / 57.29578F;
	    }
        } else
        {
	    if(!isRiding){
            bipedBody.rotateAngleX = 0.0F;
            bipedRightLeg.rotationPointZ = 0.0F;
            bipedLeftLeg.rotationPointZ = 0.0F;
            bipedRightLeg.rotationPointY = 12F;
            bipedLeftLeg.rotationPointY = 12F;
            bipedHead.rotationPointY = 0.0F;
            bipedLeftArm.rotateAngleZ = (MathHelper.cos(f * 0.2812F * speed) - 1.0F) * armsZ * f1;
            bipedRightArm.rotateAngleZ = (MathHelper.cos(f * 0.2312F * speed) + 1.0F) * armsZ * f1;
            bipedLeftLeg.rotateAngleZ = (MathHelper.cos(f * 0.2812F * speed) - 1.0F) * legsZ * f1;
            bipedRightLeg.rotateAngleZ = (MathHelper.cos(f * 0.2312F * speed) + 1.0F) * legsZ * f1;
	    bipedRightLeg.rotateAngleX = MathHelper.cos(f * 0.6662F * speed) * legsX * f1;
	    bipedLeftLeg.rotateAngleX = MathHelper.cos(f * 0.6662F * speed + 3.141593F) * legsX * f1;
	    bipedRightArm.rotateAngleZ += MathHelper.cos(f2 * 0.09F * speed) * 0.05F + 0.05F;
	    bipedLeftArm.rotateAngleZ -= MathHelper.cos(f2 * 0.09F * speed) * 0.05F + 0.05F;
	    bipedRightArm.rotateAngleX += MathHelper.sin(f2 * 0.067F * speed) * 0.05F;
	    bipedLeftArm.rotateAngleX -= MathHelper.sin(f2 * 0.067F * speed) * 0.05F;
	    bipedBody.rotationPointY = MathHelper.cos(f * -0.6662F * speed * 2F) * -upDownAmplitude * f1;
	    bipedHead.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1;
	    bipedHeadwear.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1;
	    bipedRightLeg.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1 + 12F;
	    bipedLeftLeg.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1 + 12F;
	    bipedRightArm.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1 + 2F;
	    bipedLeftArm.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1 + 2F;
	    bipedEars.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1;
	    bipedCloak.rotationPointY = MathHelper.cos(f * 0.6662F * speed * 2F) * -upDownAmplitude * f1;}
	    if(headMode==2){
		bipedHead.rotateAngleX = 0F;
		bipedHead.rotateAngleY = 0F;
		bipedHeadwear.rotateAngleX = 0F;
		bipedHeadwear.rotateAngleY = 0F;
	    }else if(headMode==3){
		bipedHead.rotateAngleY = MathHelper.sin(f * 0.23F * speed) * 1.0F * f1;
		bipedHead.rotateAngleX = MathHelper.sin(f * 0.1F * speed) * 0.80000000000000004F * f1;
		bipedHeadwear.rotateAngleY = MathHelper.sin(f * 0.23F * speed) * 1.0F * f1;
		bipedHeadwear.rotateAngleX = MathHelper.sin(f * 0.1F * speed) * 0.80000000000000004F * f1;
	    }else{
		bipedHead.rotateAngleY = f3 / 57.29578F;
		bipedHead.rotateAngleX = f4 / 57.29578F;
	    }
        }
    }

    public void renderEars(float f)
    {
        bipedEars.rotateAngleY = bipedHead.rotateAngleY;
        bipedEars.rotateAngleX = bipedHead.rotateAngleX;
        bipedEars.rotationPointX = 0.0F;
        bipedEars.rotationPointY = 0.0F;
        bipedEars.render(f);
    }

    public void renderCloak(float f)
    {
        bipedCloak.render(f);
    }

    public ModelRenderer bipedHead;
    public ModelRenderer bipedHeadwear;
    public ModelRenderer bipedBody;
    public ModelRenderer bipedRightArm;
    public ModelRenderer bipedLeftArm;
    public ModelRenderer bipedRightLeg;
    public ModelRenderer bipedLeftLeg;
    public ModelRenderer bipedEars;
    public ModelRenderer bipedCloak;
    public boolean field_1279_h;
    public boolean field_1278_i;
    public boolean isSneak;
    public static float speed;
    public static float speedSneak;
    public static float legsX;
    public static float legsXSneak;
    public static float legsZ;
    public static float legsZSneak;
    public static float armsX;
    public static float armsXSneak;
    public static float armsZ;
    public static float armsZSneak;
    public static int headMode;
    public static float upDownAmplitude;
    public static int armsMode;
    public static boolean itemInHand;
    public static boolean useSwing;
}
