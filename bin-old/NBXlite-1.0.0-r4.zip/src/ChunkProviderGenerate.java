// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode fieldsfirst 

package net.minecraft.src;

import java.util.List;
//import java.util.Random;

// Referenced classes of package net.minecraft.src:
//            IChunkProvider, MapGenCaves, MapGenStronghold, MapGenVillage, 
//            MapGenMineshaft, MapGenRavine, NoiseGeneratorOctaves, World, 
//            WorldChunkManager, Block, BiomeGenBase, Chunk, 
//            MapGenBase, MathHelper, BlockSand, WorldGenLakes, 
//            WorldGenDungeons, SpawnerAnimals, ChunkCoordIntPair, IProgressUpdate, 
//            EnumCreatureType, ChunkPosition

public class ChunkProviderGenerate
    implements IChunkProvider
{

    public ChunkProviderGenerateAlpha alphaGen;
    public ChunkProviderGenerateBeta betaGen;
    public ChunkProviderGenerate10 Gen10;
    public ChunkProviderGenerate18 Gen18;

    public ChunkProviderGenerate(World world, long l, boolean flag)
    {
        alphaGen = new ChunkProviderGenerateAlpha(world, l, flag);
        betaGen = new ChunkProviderGenerateBeta(world, l, flag);
        Gen10 = new ChunkProviderGenerate10(world, l, flag);
        Gen18 = new ChunkProviderGenerate18(world, l, flag);
    }

    public Chunk loadChunk(int i, int j)
    {
        return provideChunk(i, j);
    }

    public Chunk provideChunk(int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            return alphaGen.provideChunk(i, j);
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.provideChunk(i, j);
        } else if(mod_noBiomesX.Generator==2)
        {
            return Gen10.provideChunk(i, j);
        } else
        {
            return Gen18.provideChunk(i, j);
        }
    }

    public boolean chunkExists(int i, int j)
    {
        return true;
    }

    public void populate(IChunkProvider ichunkprovider, int i, int j)
    {
        if(mod_noBiomesX.Generator==0)
        {
            alphaGen.populate(ichunkprovider, i, j);
        } else if(mod_noBiomesX.Generator==1)
        {
            betaGen.populate(ichunkprovider, i, j);
        } else if(mod_noBiomesX.Generator==2)
        {
            Gen10.populate(ichunkprovider, i, j);
        } else
        {
            Gen18.populate(ichunkprovider, i, j);
        }
    }

    public boolean saveChunks(boolean flag, IProgressUpdate iprogressupdate)
    {
        return true;
    }

    public boolean unload100OldestChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public String makeString()
    {
        return "RandomLevelSource";
    }

    public List func_40377_a(EnumCreatureType enumcreaturetype, int i, int j, int k)
    {
        return null;
    }

    public ChunkPosition func_40376_a(World world, String s, int i, int j, int k)
    {
        if(mod_noBiomesX.Generator==0)
        {
            return alphaGen.func_40376_a(world, s, i, j, k);
        } else if(mod_noBiomesX.Generator==1)
        {
            return betaGen.func_40376_a(world, s, i, j, k);
        } else if(mod_noBiomesX.Generator==2)
        {
            return Gen10.func_40376_a(world, s, i, j, k);
        } else
        {
            return Gen18.func_40376_a(world, s, i, j, k);
        }
    }
}
