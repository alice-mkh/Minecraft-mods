// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode fieldsfirst 

package net.minecraft.src;

import java.io.PrintStream;
import java.util.Random;

// Referenced classes of package net.minecraft.src:
//            MapGenStronghold

public class MapGenSkyStronghold extends MapGenStronghold
{

    public MapGenSkyStronghold()
    {
    }

    protected boolean canSpawnStructureAtCoords(int i, int j)
    {
        boolean flag = rand.nextInt(200) == 0 && rand.nextInt(120) < Math.max(Math.abs(i), Math.abs(j));
        if(flag)
        {
            System.out.printf("generating stronghold at chunk %d, %d!\n", new Object[] {
                Integer.valueOf(i * 16), Integer.valueOf(j * 16)
            });
        }
        return flag;
    }
}
