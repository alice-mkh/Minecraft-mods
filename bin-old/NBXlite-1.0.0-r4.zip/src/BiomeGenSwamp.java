// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode fieldsfirst 

package net.minecraft.src;

import java.util.Random;

// Referenced classes of package net.minecraft.src:
//            BiomeGenBase, BiomeDecorator, IBlockAccess, WorldChunkManager, 
//            ColorizerGrass, ColorizerFoliage, WorldGenerator

public class BiomeGenSwamp extends BiomeGenBase
{

    protected BiomeGenSwamp(int i)
    {
        super(i);
        biomeDecorator.treesPerChunk = 2;
        biomeDecorator.flowersPerChunk = -999;
        biomeDecorator.deadBushPerChunk = 1;
        biomeDecorator.mushroomsPerChunk = 8;
        biomeDecorator.reedsPerChunk = 10;
        biomeDecorator.clayPerChunk = 1;
        waterColorMultiplier = 0xe0ff70;
        if (mod_noBiomesX.Generator==2){
            biomeDecorator.waterlilyPerChunk = 4;
        }else{
            biomeDecorator.waterlilyPerChunk = 0;
        }
    }

    public WorldGenerator getRandomWorldGenForTrees(Random random)
    {
        return worldGenSwamp;
    }

    public int getGrassColorAtCoords(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if (mod_noBiomesX.Generator==2){
            double d = iblockaccess.getWorldChunkManager().func_35554_b(i, j, k);
            double d1 = iblockaccess.getWorldChunkManager().func_35558_c(i, k);
            return ((ColorizerGrass.getGrassColor(d, d1) & 0xfefefe) + 0x4e0e4e) / 2;
        }else{
            return 0x8baf48;
        }
    }

    public int getFoliageColorAtCoords(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if (mod_noBiomesX.Generator==2){
            double d = iblockaccess.getWorldChunkManager().func_35554_b(i, j, k);
            double d1 = iblockaccess.getWorldChunkManager().func_35558_c(i, k);
            return ((ColorizerFoliage.getFoliageColor(d, d1) & 0xfefefe) + 0x4e0e4e) / 2;
        }else{
            return 0x8baf48;
        }
    }
}
