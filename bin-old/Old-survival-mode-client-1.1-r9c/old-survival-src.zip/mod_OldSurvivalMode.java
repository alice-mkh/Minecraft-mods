package net.minecraft.src;

import java.io.*;
import net.minecraft.client.Minecraft;

public class mod_OldSurvivalMode extends BaseMod{
    public String getVersion(){
        return "1.1";
    }

    public mod_OldSurvivalMode(){
        OldSurvivalModeProperties oldsurvivalmodeproperties = new OldSurvivalModeProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                oldsurvivalmodeproperties.setProperty("AnimalsFleeWhenDamaged", Boolean.toString(false));
                oldsurvivalmodeproperties.setProperty("DisableFoodStacking", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("InstantBow", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("InstantFood", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("DisableHunger", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("DisableXP", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("OldCombatSystem", Boolean.toString(true));
                oldsurvivalmodeproperties.setProperty("OldArmor", Boolean.toString(true));
                oldsurvivalmodeproperties.store(fileoutputstream, "Survival mode config");

                fileoutputstream.close();
            }
            oldsurvivalmodeproperties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/OldSurvivalMode.properties").toString()));
            DisableXP = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableXP"));
            DisableHunger = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableHunger"));
            InstantFood = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantFood"));
            InstantBow = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("InstantBow"));
            DisableFoodStacking = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("DisableFoodStacking"));
            AnimalsFlee = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("AnimalsFleeWhenDamaged"));
            OldCombatSystem = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("OldCombatSystem"));
            OldArmor = Boolean.parseBoolean(oldsurvivalmodeproperties.getProperty("OldArmor"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
        ModLoader.SetInGameHook(this, true, true);
        SetSwordDamage(OldCombatSystem);
        SetArmorDamage(OldArmor);
    }
    
    public void SetSwordDamage(boolean b){
        try{
            if (b){
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordDiamond, "weaponDamage", 10);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordSteel, "weaponDamage", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordStone, "weaponDamage", 6);
            }else{
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordDiamond, "weaponDamage", 7);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordSteel, "weaponDamage", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordStone, "weaponDamage", 5);
            }
            ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordWood, "weaponDamage", 4);
            ModLoader.setPrivateValue(net.minecraft.src.ItemSword.class, Item.swordGold, "weaponDamage", 4);
        }catch(Exception exception){
            System.out.println("WTF?");
        }
    }
    
    public void SetArmorDamage(boolean b){
        try{
            if (b){
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "damageReduceAmount", 8);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetLeather, "maxDamage", 33 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetChain, "maxDamage", 33 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetSteel, "maxDamage", 33 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetGold, "maxDamage", 33 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetDiamond, "maxDamage", 33 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateLeather, "maxDamage", 48 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateChain, "maxDamage", 48 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateSteel, "maxDamage", 48 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateGold, "maxDamage", 48 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateDiamond, "maxDamage", 48 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsLeather, "maxDamage", 45 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsChain, "maxDamage", 45 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsSteel, "maxDamage", 45 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsGold, "maxDamage", 45 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsDiamond, "maxDamage", 45 << 3);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsLeather, "maxDamage", 39 << 0);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsChain, "maxDamage", 39 << 1);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsSteel, "maxDamage", 39 << 2);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsGold, "maxDamage", 39 << 4);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsDiamond, "maxDamage", 39 << 3);
            }else{
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetLeather, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetChain, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetSteel, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetGold, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateLeather, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateChain, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateSteel, "damageReduceAmount", 6);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateGold, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsLeather, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsChain, "damageReduceAmount", 4);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsSteel, "damageReduceAmount", 5);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsGold, "damageReduceAmount", 3);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsLeather, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsChain, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsSteel, "damageReduceAmount", 2);
                ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsGold, "damageReduceAmount", 1);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetLeather, "maxDamage", 55);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetChain, "maxDamage", 165);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetSteel, "maxDamage", 165);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetGold, "maxDamage", 77);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.helmetDiamond, "maxDamage", 363);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateLeather, "maxDamage", 80);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateChain, "maxDamage", 240);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateSteel, "maxDamage", 240);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateGold, "maxDamage", 112);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.plateDiamond, "maxDamage", 528);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsLeather, "maxDamage", 75);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsChain, "maxDamage", 225);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsSteel, "maxDamage", 225);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsGold, "maxDamage", 105);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.legsDiamond, "maxDamage", 495);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsLeather, "maxDamage", 65);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsChain, "maxDamage", 195);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsSteel, "maxDamage", 195);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsGold, "maxDamage", 91);
                ModLoader.setPrivateValue(net.minecraft.src.Item.class, Item.bootsDiamond, "maxDamage", 429);
            }
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.helmetDiamond, "damageReduceAmount", 3);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.plateDiamond, "damageReduceAmount", 8);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.legsDiamond, "damageReduceAmount", 6);
            ModLoader.setPrivateValue(net.minecraft.src.ItemArmor.class, Item.bootsDiamond, "damageReduceAmount", 3);
        }catch(Exception exception){
            System.out.println("WTF?");
        }
    }

    public boolean OnTickInGame(float f, Minecraft minecraft){
/*
        for (int k = 0; k < minecraft.theWorld.loadedEntityList.size(); k++)
        {
            if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityAnimal && !AnimalsFlee){
                EntityAnimal entity = (EntityAnimal)minecraft.theWorld.loadedEntityList.get(k);
                entity.fleeingTick=0;
            }else if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityXPOrb && DisableXP){
                EntityXPOrb entity = (EntityXPOrb)minecraft.theWorld.loadedEntityList.get(k);
                entity.setEntityDead();
            }
        }
        return true;
*/
        if (AnimalsFlee){
            return true;
        }
        EntityAnimal entity;
        for (int k = 0; k < minecraft.theWorld.loadedEntityList.size(); k++)
        {
            if ((Entity)minecraft.theWorld.loadedEntityList.get(k) instanceof EntityAnimal){
                entity = (EntityAnimal)minecraft.theWorld.loadedEntityList.get(k);
                entity.fleeingTick=0;
            }
        }
        return true;
    }

    public void load(){};

    public static boolean DisableXP;
    public static boolean DisableHunger;
    public static boolean InstantFood;
    public static boolean InstantBow;
    public static boolean DisableFoodStacking;
    public static boolean AnimalsFlee;
    public static boolean OldCombatSystem;
    public static boolean OldArmor= true;
}