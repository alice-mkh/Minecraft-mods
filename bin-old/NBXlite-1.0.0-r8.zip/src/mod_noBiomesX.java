package net.minecraft.src;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.io.*;

public class mod_noBiomesX extends BaseMod{
    public mod_noBiomesX(){
        NBXliteProperties properties = new NBXliteProperties();
        try{
            File file = new File((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString());
            boolean flag = file.createNewFile();
            if(flag){
                FileOutputStream fileoutputstream = new FileOutputStream(file);
                properties.setProperty("DefaultGenerator",Integer.toString(2));
                properties.setProperty("DefaultFeatures",Integer.toString(2));
                properties.setProperty("DefaultTheme",Integer.toString(0));
                properties.store(fileoutputstream,"NBXlite properties");
                fileoutputstream.close();
            }
            properties.load(new FileInputStream((new StringBuilder()).append(Minecraft.getMinecraftDir()).append("/config/NBXlite.properties").toString()));
            DefaultGenerator = Integer.parseInt(properties.getProperty("DefaultGenerator"));
            DefaultFeatures = Integer.parseInt(properties.getProperty("DefaultFeatures"));
            DefaultTheme = Integer.parseInt(properties.getProperty("DefaultTheme"));
        }
        catch(IOException ioexception){
            ioexception.printStackTrace();
        }
    }
    
    public void load(){
        Block.grass.toptex = ModLoader.addOverride("/terrain.png", "/nbx/grasstop.png");
        Block.grass.sidetex = ModLoader.addOverride("/terrain.png", "/nbx/grassside.png");
        Block.leaves.fasttex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfast.png");
        Block.leaves.fancytex = ModLoader.addOverride("/terrain.png", "/nbx/leavesfancy.png");
    }

    public String getVersion(){
        return "1.0.0";
    }

    public static int Generator = 1; //0 - alpha; 1 - halloween/beta; 2 - 1.0
    public static boolean OldSpawners = false;
    public static boolean GenerateSandstone = false;
    public static boolean GenerateLapis = false;
    public static boolean SunriseEffect = false;
    public static boolean SnowCovered = false;
    public static boolean LowHangingClouds = true;
    public static boolean OverrideGenerateStructures;
    public static boolean ClassicLight=true;
    public static int LightTintRed = 255;
    public static int LightTintGreen = 255;
    public static int LightTintBlue = 255;
    public static boolean VoidFog=true;
    public static int MapType = 0;   //0 - normal; 1 - hell; 2 - woods; 3 - paradise
    public static int MapFeatures;   //0 - nothing; 1 - special trees and lakes; 2 - tall grass and weather
    public static int DefaultGenerator;
    public static int DefaultFeatures;
    public static int DefaultTheme;
}