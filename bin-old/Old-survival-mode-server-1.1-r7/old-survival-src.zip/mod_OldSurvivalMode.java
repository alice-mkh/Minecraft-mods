package net.minecraft.src;

import net.minecraft.server.MinecraftServer;

public class mod_OldSurvivalMode extends BaseModMp{
    public mod_OldSurvivalMode(){
        ModLoader.SetInGameHook(this, true, true);
    }

    public void load(){}

    public String getVersion(){
        return "1.1.0";
    }

    public void OnTickInGame(MinecraftServer minecraft){
        EntityAnimal entity;
        for (int l = 0; l < minecraft.worldMngr.length; l++){
            for (int k = 0; k < minecraft.worldMngr[l].loadedEntityList.size(); k++)
            {
                if ((Entity)minecraft.worldMngr[l].loadedEntityList.get(k) instanceof EntityAnimal){
                    entity = (EntityAnimal)minecraft.worldMngr[l].loadedEntityList.get(k);
                    entity.fleeingTick=0;
                }
            }
        }
        return;
    }

    public boolean hasClientSide()
    {
        return false;
    }
}